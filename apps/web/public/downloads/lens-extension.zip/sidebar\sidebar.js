"use strict";
(() => {
  // content/bridge.ts
  var seq = 0;
  function nextRequestId() {
    seq += 1;
    return `req_${Date.now().toString(36)}_${seq}`;
  }
  function postToParent(msg) {
    const withId = { requestId: msg.requestId ?? nextRequestId(), ...msg };
    window.parent.postMessage(withId, "*");
  }
  function onContentMessage(handler) {
    const fn = (e) => {
      if (e.source !== window.parent) return;
      if (!e.data || typeof e.data !== "object") return;
      if (typeof e.data.type !== "string") return;
      handler(e.data);
    };
    window.addEventListener("message", fn);
    return () => window.removeEventListener("message", fn);
  }

  // sidebar/sidebar.ts
  var $ = (id) => document.getElementById(id);
  var root = () => $("root");
  function esc(s) {
    return (s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  }
  function announceReady() {
    postToParent({ type: "ready", payload: {} });
  }
  function requestClose() {
    postToParent({ type: "request-close", payload: {} });
  }
  $("close-btn").addEventListener("click", requestClose);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") requestClose();
  });
  onContentMessage((msg) => {
    if (msg.type === "init") {
      void runAudit(msg.payload);
    } else if (msg.type === "close") {
      requestClose();
    }
  });
  announceReady();
  async function runAudit(init) {
    root().innerHTML = `
    <div class="card">
      <div class="card-header">
        <div>
          <h2>Auditing\u2026</h2>
          <p class="card-subtitle">Host: <strong>${esc(init.host)}</strong></p>
        </div>
      </div>
      <ul class="stream" id="stream"></ul>
    </div>
  `;
    const streamEl = $("stream");
    streamEl.append(li("init \xB7 reading assistant response"));
    let finalResult = null;
    const body = {
      kind: "text",
      source: init.host === "unknown" ? "unknown" : init.host,
      raw: init.responseText
    };
    if (init.userPrompt) body["userPrompt"] = init.userPrompt;
    void tailStream(init.apiBase, body, streamEl);
    try {
      const res = await fetch(`${init.apiBase}/audit`, {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json", ...getAnonHeader() },
        body: JSON.stringify(body)
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      finalResult = await res.json();
    } catch (e) {
      streamEl.append(li(`audit failed: ${e.message}`));
      return;
    }
    renderResult(finalResult);
  }
  async function tailStream(apiBase, body, logEl) {
    try {
      const res = await fetch(`${apiBase}/audit/stream`, {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json", ...getAnonHeader() },
        body: JSON.stringify(body)
      });
      if (!res.ok || !res.body) return;
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buf = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        const parts = buf.split("\n\n");
        buf = parts.pop() ?? "";
        for (const chunk of parts) {
          const event = chunk.match(/^event: (.+)$/m)?.[1];
          const dataJson = chunk.match(/^data: (.+)$/m)?.[1];
          if (!event || !dataJson) continue;
          try {
            const data = JSON.parse(dataJson);
            logEl.append(li(labelFor(event, data)));
          } catch {
            logEl.append(li(event));
          }
        }
      }
    } catch {
    }
  }
  function labelFor(event, data) {
    const d = data;
    if (event.endsWith(":start")) return `${event} \xB7 ${JSON.stringify(d).slice(0, 90)}`;
    if (event.endsWith(":done")) return `${event} \xB7 ${JSON.stringify(d).slice(0, 120)}`;
    if (event === "done") return "pipeline complete";
    return event;
  }
  function li(text) {
    const el = document.createElement("li");
    el.textContent = text;
    return el;
  }
  function getAnonHeader() {
    try {
      const v = window.localStorage.getItem("lens.anon.v1");
      return v ? { "x-lens-anon-id": v } : {};
    } catch {
      return {};
    }
  }
  function renderResult(r) {
    const banner = verdictBanner(r);
    const hero = heroPick(r);
    const criteria = criteriaCard(r);
    const claims = r.claims.length > 0 ? claimsCard(r) : "";
    const cross = crossModelCard(r);
    const elapsed = `<p class="elapsed">${(r.elapsedMs.total / 1e3).toFixed(1)}s end-to-end</p>`;
    root().innerHTML = `
    <div class="card">
      <div class="card-header">
        <div>
          <h2>Lens audit</h2>
          <p class="card-subtitle">Category: <strong>${esc(r.intent.category)}</strong></p>
        </div>
      </div>
      ${banner}
      ${hero}
    </div>
    ${criteria}
    ${claims}
    ${cross}
    ${elapsed}
  `;
    wireSliders(r);
  }
  function verdictBanner(r) {
    const total = r.claims.length;
    if (total === 0) return "";
    const f = r.claims.filter((c) => c.verdict === "false").length;
    const m = r.claims.filter((c) => c.verdict === "misleading").length;
    const t = r.claims.filter((c) => c.verdict === "true").length;
    const u = total - f - m - t;
    const summary = `${f} false \xB7 ${m} misleading \xB7 ${t} verified \xB7 ${u} unverifiable`;
    if (f > 0)
      return `<div class="verdict bad"><span class="verdict-icon">\u2717</span><span><strong>Lens flagged ${f} false claim${f === 1 ? "" : "s"}.</strong>${esc(summary)}</span></div>`;
    if (m > 0)
      return `<div class="verdict mixed"><span class="verdict-icon">\u26A0</span><span><strong>Lens flagged ${m} misleading claim${m === 1 ? "" : "s"}.</strong>${esc(summary)}</span></div>`;
    return `<div class="verdict good"><span class="verdict-icon">\u2713</span><span><strong>Every claim checks out.</strong>${esc(summary)}</span></div>`;
  }
  function heroPick(r) {
    const o = r.specOptimal;
    return `
    <div class="hero-pick">
      <div class="pick-product">
        <span class="brand">${esc(o.brand ?? "")}</span><span class="name">${esc(o.name)}</span>
      </div>
      <div class="pick-price">Price: <span class="amount">$${o.price ?? "?"}</span> \xB7 <span class="muted">Best fit for your stated criteria</span></div>
    </div>
  `;
  }
  function criteriaCard(r) {
    return `
    <div class="card">
      <div class="card-header">
        <div>
          <h2>Your criteria</h2>
          <p class="card-subtitle">Drag to re-weight. Ranking updates live.</p>
        </div>
      </div>
      <div class="sliders" id="sliders-wrap">
        ${r.intent.criteria.map((c) => `
          <div class="slider-row">
            <div class="name">${esc(c.name)}</div>
            <input type="range" min="0" max="100" value="${Math.round(c.weight * 100)}" data-name="${esc(c.name)}" />
            <div class="value" data-for="${esc(c.name)}">${Math.round(c.weight * 100)}%</div>
          </div>
        `).join("")}
      </div>
    </div>
  `;
  }
  function claimsCard(r) {
    return `
    <div class="card">
      <div class="card-header">
        <div>
          <h2>AI's claims, checked</h2>
          <p class="card-subtitle">${r.claims.length} claim${r.claims.length === 1 ? "" : "s"} verified against live spec sheets.</p>
        </div>
      </div>
      ${r.claims.map((c) => {
      const icon = { true: "\u2713", false: "\u2717", misleading: "\u26A0", unverifiable: "?" }[c.verdict] ?? "?";
      return `
          <div class="claim ${c.verdict}">
            <div class="icon">${icon}</div>
            <div>
              <span class="attr">${esc(c.attribute)}</span><span class="value">${esc(c.statedValue)}</span>
              ${c.note ? `<div class="note">${esc(c.note)}</div>` : ""}
            </div>
          </div>
        `;
    }).join("")}
    </div>
  `;
  }
  function crossModelCard(r) {
    if (r.crossModel.length === 0) {
      return `<div class="card"><div class="card-header"><h2>Other models</h2></div><p class="muted" style="margin:0;">No cross-model picks for this run.</p></div>`;
    }
    return `
    <div class="card">
      <div class="card-header">
        <div>
          <h2>What other models picked</h2>
          <p class="card-subtitle">Parallel fan-out via a separate Managed Agent Worker.</p>
        </div>
      </div>
      ${r.crossModel.map((c) => `
        <div class="cross-row">
          <div>
            <span class="provider">${esc(c.provider)}</span>
            <span class="pick">${esc((c.pickedProduct.name || "").split("\n")[0].slice(0, 60))}</span>
          </div>
          <div class="verdict-badge ${c.agreesWithLens ? "agrees" : "disagrees"}">
            ${c.agreesWithLens ? "agrees" : "sides with host"}
          </div>
        </div>
      `).join("")}
    </div>
  `;
  }
  function wireSliders(r) {
    const wrap = document.getElementById("sliders-wrap");
    if (!wrap) return;
    wrap.addEventListener("input", (e) => {
      const input = e.target;
      if (input.type !== "range") return;
      const name = input.dataset["name"];
      if (!name) return;
      const valEl = wrap.querySelector(`[data-for="${name}"]`);
      if (valEl) valEl.textContent = `${input.value}%`;
      reRank(r);
    });
  }
  function reRank(r) {
    const wraps = document.querySelectorAll(".sliders input[type='range']");
    const raw = {};
    let sum = 0;
    for (const s of wraps) {
      const v = Number(s.value);
      raw[s.dataset["name"] ?? ""] = v;
      sum += v;
    }
    const norm = {};
    for (const [k, v] of Object.entries(raw)) norm[k] = sum > 0 ? v / sum : 0;
    let topName = r.specOptimal.name;
    let topScore = 0;
    for (const cand of r.candidates) {
      let u = 0;
      for (const b of cand.utilityBreakdown) u += (norm[b.criterion] ?? 0) * b.score;
      if (u > topScore) {
        topScore = u;
        topName = cand.name;
      }
    }
    const hero = document.querySelector(".hero-pick .name");
    if (hero) hero.textContent = topName;
  }
})();

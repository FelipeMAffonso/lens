"use strict";
(() => {
  // content/overlay/suppression.ts
  var KEY_PREFIX = "lens.suppress.v1";
  var DISMISS_THRESHOLD = 3;
  var SUPPRESS_WINDOW_MS = 7 * 24 * 60 * 60 * 1e3;
  function keyOf(host, patternId) {
    return `${KEY_PREFIX}.${host}.${patternId}`;
  }
  function readSync(key) {
    try {
      const s = typeof localStorage !== "undefined" && localStorage.getItem(key) || null;
      return s ? JSON.parse(s) : null;
    } catch {
      return null;
    }
  }
  function writeSync(key, rec) {
    try {
      if (typeof localStorage !== "undefined") localStorage.setItem(key, JSON.stringify(rec));
    } catch {
    }
  }
  function shouldSuppress(host, patternId) {
    const rec = readSync(keyOf(host, patternId));
    if (!rec) return false;
    if (rec.suppressedUntil && rec.suppressedUntil > Date.now()) return true;
    return false;
  }
  function recordDismissal(host, patternId) {
    const k = keyOf(host, patternId);
    const now = Date.now();
    const cur = readSync(k) ?? { count: 0, firstAt: now, lastAt: now };
    cur.count += 1;
    cur.lastAt = now;
    if (cur.count >= DISMISS_THRESHOLD) {
      cur.suppressedUntil = now + SUPPRESS_WINDOW_MS;
    }
    writeSync(k, cur);
  }

  // content/overlay/badge.ts
  var BADGE_ATTR = "data-lens-badge";
  var BADGE_REGISTRY = /* @__PURE__ */ new WeakMap();
  var TEMPLATE = `
<style>
  :host, button { all: initial; box-sizing: border-box; }
  * { box-sizing: border-box; }
  .root {
    position: absolute; top: -4px; right: -4px; z-index: 2147483646;
    pointer-events: auto; font: 500 12px/1.4 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  }
  .pill {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 5px 9px 5px 8px; background: #fff6f2; color: #b13b30;
    border: 1px solid rgba(226, 89, 80, 0.32);
    border-radius: 999px; cursor: pointer;
    box-shadow: 0 1px 4px rgba(15, 20, 30, 0.16);
    transform: scale(1);
    transition: transform 150ms cubic-bezier(0.22, 1, 0.36, 1),
                box-shadow 150ms ease, background 150ms ease;
    max-width: 240px;
  }
  .pill:hover { transform: scale(1.03); box-shadow: 0 2px 8px rgba(15, 20, 30, 0.22); }
  .pill:focus-visible { outline: none; box-shadow: 0 0 0 3px rgba(226, 89, 80, 0.25); }
  .dot { width: 6px; height: 6px; border-radius: 999px; background: #e25950; flex-shrink: 0; }
  .name { font-weight: 600; }
  .close { background: none; border: 0; color: rgba(177, 59, 48, 0.75); cursor: pointer; padding: 0 2px; margin-left: 2px; font-size: 13px; line-height: 1; }
  .close:hover { color: #b13b30; }
  .tooltip {
    position: absolute; bottom: calc(100% + 6px); right: 0;
    background: #1a1a1a; color: #fafbfc;
    padding: 8px 10px; border-radius: 6px; white-space: nowrap;
    opacity: 0; transform: translateY(4px); pointer-events: none;
    transition: opacity 150ms ease, transform 150ms ease;
    font-size: 11px; line-height: 1.45; max-width: 320px; white-space: normal;
  }
  .pill:hover ~ .tooltip, .pill:focus-visible ~ .tooltip { opacity: 1; transform: translateY(0); }
  @keyframes enter {
    from { opacity: 0; transform: translateY(-4px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .root { animation: enter 200ms cubic-bezier(0.22, 1, 0.36, 1); }
  @media (prefers-reduced-motion: reduce) {
    .root, .pill { animation: none; transition: none; }
  }
</style>
<div class="root" role="alert" aria-live="polite">
  <button type="button" class="pill" aria-label="Dark pattern detected">
    <span class="dot" aria-hidden="true"></span>
    <span class="name">PATTERN</span>
    <span class="close" data-close aria-label="Dismiss">\xD7</span>
  </button>
  <span class="tooltip">TOOLTIP</span>
</div>
`;
  function attachDarkPatternBadge(anchor, hit, onClick) {
    if (shouldSuppress(window.location.host, hit.brignullId)) return null;
    if (anchor.getAttribute(BADGE_ATTR) === hit.brignullId) return null;
    const cs = window.getComputedStyle(anchor);
    if (cs.position === "static") anchor.style.position = "relative";
    const host = document.createElement("span");
    host.style.cssText = "display:inline-block;position:relative;line-height:0;";
    host.setAttribute("data-lens", "badge-host");
    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = TEMPLATE.replace("PATTERN", labelFor(hit.brignullId)).replace("TOOLTIP", tooltipFor(hit));
    const pill = shadow.querySelector(".pill");
    const closeBtn = shadow.querySelector("[data-close]");
    pill.addEventListener("click", (e) => {
      if (e.target.hasAttribute("data-close")) return;
      e.preventDefault();
      e.stopPropagation();
      onClick?.(hit);
    });
    closeBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      recordDismissal(window.location.host, hit.brignullId);
      host.remove();
      anchor.removeAttribute(BADGE_ATTR);
    });
    anchor.append(host);
    anchor.setAttribute(BADGE_ATTR, hit.brignullId);
    BADGE_REGISTRY.set(host, { shadow, hit });
    return host;
  }
  function upgradeBadge(host, confirmation) {
    const entry = BADGE_REGISTRY.get(host);
    if (!entry) return;
    const { shadow, hit } = entry;
    const pill = shadow.querySelector(".pill");
    const dot = shadow.querySelector(".dot");
    const tooltip = shadow.querySelector(".tooltip");
    if (!pill || !dot || !tooltip) return;
    if (confirmation.verdict === "confirmed") {
      dot.style.background = "#1f7a55";
      pill.setAttribute("aria-label", "Dark pattern confirmed by Lens Stage 2");
    } else {
      dot.style.background = "#c98a1a";
      pill.setAttribute("aria-label", "Possible dark pattern flagged by Lens");
    }
    const parts = [];
    parts.push(confirmation.llmExplanation || hit.matchedElement.text.slice(0, 120));
    if (confirmation.regulatoryCitation) {
      const c = confirmation.regulatoryCitation;
      parts.push(`
${c.officialName} \xB7 ${c.citation}${c.status === "in-force" ? "" : ` (${c.status})`}.`);
      if (c.userRightsPlainLanguage) parts.push(c.userRightsPlainLanguage.slice(0, 240));
    }
    if (confirmation.feeBreakdown?.amountUsd) {
      const f = confirmation.feeBreakdown;
      const freq = f.frequency ? ` ${f.frequency}` : "";
      parts.push(`
Fee: ${f.label} \u2014 $${f.amountUsd}${freq}.`);
    }
    tooltip.textContent = parts.join(" ");
  }
  function findBadgeByBrignullId(brignullId) {
    const all = document.querySelectorAll(`[${BADGE_ATTR}='${brignullId}']`);
    for (const anchor of all) {
      const host = anchor.querySelector("[data-lens='badge-host']");
      if (host) return host;
    }
    return null;
  }
  function labelFor(id) {
    return id.replace(/-/g, " ");
  }
  function tooltipFor(hit) {
    return `${hit.severity.toUpperCase()} \xB7 Lens caught a ${hit.brignullId.replace(/-/g, " ")} pattern. Click for remediation.`;
  }

  // content/overlay/snackbar.ts
  var SNACKBAR_ID = "lens-snackbar";
  function renderAggregateSnackbar(hits, onOpen) {
    const existing = document.getElementById(SNACKBAR_ID);
    if (existing) existing.remove();
    if (hits.length === 0) return;
    const host = document.createElement("div");
    host.id = SNACKBAR_ID;
    host.style.cssText = `
    position: fixed; bottom: 16px; right: 16px; z-index: 2147483646;
    font: 500 13px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  `;
    const shadow = host.attachShadow({ mode: "closed" });
    const byPattern = groupBy(hits, (h) => h.brignullId);
    const patternList = Array.from(byPattern.entries()).map(([id, hs]) => `${id.replace(/-/g, " ")} (${hs.length})`).join(" \xB7 ");
    shadow.innerHTML = `
    <style>
      :host, button { all: initial; box-sizing: border-box; }
      * { box-sizing: border-box; }
      .card {
        background: #1a1a1a; color: #fafbfc;
        padding: 12px 14px; border-radius: 8px;
        box-shadow: 0 8px 28px rgba(15,20,30,0.35);
        display: grid; gap: 8px; max-width: 360px;
        font: 500 13px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      }
      .head { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; }
      .title { font-weight: 700; color: #fafbfc; font-size: 13px; }
      .list { color: #c8ced7; font-size: 12px; line-height: 1.45; }
      .actions { display: flex; gap: 8px; }
      .btn {
        background: #DA7756; color: #fff; border: 0;
        padding: 6px 12px; border-radius: 4px; cursor: pointer;
        font: 600 12px/1 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        transition: background 150ms ease;
      }
      .btn:hover { background: #c86a4a; }
      .btn.alt { background: transparent; color: #c8ced7; border: 1px solid rgba(200,206,215,0.35); }
      .btn.alt:hover { background: rgba(200,206,215,0.08); color: #fafbfc; }
      .close { background: none; border: 0; color: #9aa4b8; cursor: pointer; padding: 0 2px; font-size: 16px; line-height: 1; }
      @keyframes enter {
        from { opacity: 0; transform: translateY(8px); }
        to { opacity: 1; transform: translateY(0); }
      }
      .card { animation: enter 250ms cubic-bezier(0.22, 1, 0.36, 1); }
      @media (prefers-reduced-motion: reduce) { .card { animation: none; } }
    </style>
    <div class="card" role="alert" aria-live="polite">
      <div class="head">
        <span class="title">\u26A0 ${hits.length} dark pattern${hits.length === 1 ? "" : "s"} detected</span>
        <button type="button" class="close" data-close aria-label="Dismiss">\xD7</button>
      </div>
      <div class="list">${escapeHtml(patternList)}</div>
      <div class="actions">
        <button type="button" class="btn" data-open>See details</button>
        <button type="button" class="btn alt" data-close>Dismiss</button>
      </div>
    </div>
  `;
    document.body.append(host);
    shadow.querySelectorAll("[data-close]").forEach(
      (el) => el.addEventListener("click", (e) => {
        e.preventDefault();
        host.remove();
      })
    );
    shadow.querySelector("[data-open]").addEventListener("click", () => {
      onOpen?.();
      host.remove();
    });
  }
  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  }
  function groupBy(xs, key) {
    const out = /* @__PURE__ */ new Map();
    for (const x of xs) {
      const k = key(x);
      const v = out.get(k);
      if (v) v.push(x);
      else out.set(k, [x]);
    }
    return out;
  }

  // darkPatterns.ts
  var URGENCY_PATTERNS = /ends in \d+:\d+|hurry.+offer|flash sale.+today|limited time only|deal expires in/i;
  var SCARCITY_PATTERNS = /only \d+ (left|remaining)|almost sold out|\d+ (viewing|looking at) (this|right now)/i;
  var CONFIRMSHAME_PATTERNS = /no thanks, i (don.?t|do not) want|i.?m fine paying full price|i don.?t care about|i hate (good )?deals/i;
  var HIDDEN_COST_KEYWORDS = /service fee|convenience fee|processing fee|handling fee|resort fee|destination fee|facility fee/i;
  var FORCED_CONTINUITY_PATTERNS = /free trial.+(auto-?renew|automatically charged|unless you cancel)|first month free.+auto/i;
  function scanDocument(doc = document) {
    const hits = [];
    doc.querySelectorAll(
      "[class*='countdown'], [class*='timer'], [data-countdown], .deal-timer, .flash-sale"
    ).forEach((el) => {
      hits.push({
        packSlug: "dark-pattern/fake-urgency",
        brignullId: "fake-urgency",
        severity: "deceptive",
        matchedElement: {
          tag: el.tagName,
          text: el.innerText?.slice(0, 120) ?? "",
          selector: el.className || void 0
        }
      });
    });
    doc.querySelectorAll("body *").forEach((el) => {
      const text = el.innerText?.slice(0, 200);
      if (text && URGENCY_PATTERNS.test(text) && el.children.length === 0) {
        hits.push({
          packSlug: "dark-pattern/fake-urgency",
          brignullId: "fake-urgency",
          severity: "deceptive",
          matchedElement: { tag: el.tagName, text }
        });
      }
    });
    doc.querySelectorAll(".stock-counter, [data-stock], .urgency-badge").forEach((el) => {
      hits.push({
        packSlug: "dark-pattern/fake-scarcity",
        brignullId: "fake-scarcity",
        severity: "deceptive",
        matchedElement: { tag: el.tagName, text: el.innerText?.slice(0, 120) ?? "" }
      });
    });
    const bodyText = doc.body?.innerText ?? "";
    for (const m of bodyText.matchAll(new RegExp(SCARCITY_PATTERNS.source, SCARCITY_PATTERNS.flags + "g"))) {
      hits.push({
        packSlug: "dark-pattern/fake-scarcity",
        brignullId: "fake-scarcity",
        severity: "deceptive",
        matchedElement: { tag: "text", text: m[0] }
      });
    }
    doc.querySelectorAll("button, a[role='button']").forEach((el) => {
      const text = (el.innerText ?? "").slice(0, 200);
      if (CONFIRMSHAME_PATTERNS.test(text)) {
        hits.push({
          packSlug: "dark-pattern/confirmshaming",
          brignullId: "confirmshaming",
          severity: "manipulative",
          matchedElement: { tag: el.tagName, text }
        });
      }
    });
    const url = doc.location.href.toLowerCase();
    if (url.includes("checkout") || url.includes("cart") || url.includes("payment")) {
      if (HIDDEN_COST_KEYWORDS.test(bodyText)) {
        hits.push({
          packSlug: "dark-pattern/hidden-costs",
          brignullId: "hidden-costs",
          severity: "deceptive",
          matchedElement: {
            tag: "text",
            text: bodyText.match(HIDDEN_COST_KEYWORDS)?.[0] ?? "fee keyword"
          }
        });
      }
    }
    if (FORCED_CONTINUITY_PATTERNS.test(bodyText)) {
      hits.push({
        packSlug: "dark-pattern/forced-continuity",
        brignullId: "forced-continuity",
        severity: "deceptive",
        matchedElement: { tag: "text", text: bodyText.match(FORCED_CONTINUITY_PATTERNS)?.[0] ?? "" }
      });
    }
    doc.querySelectorAll("input[type='checkbox'][checked], input[type='checkbox'][data-default='checked']").forEach((el) => {
      const label = el.closest("label")?.innerText ?? el.getAttribute("name") ?? "";
      if (/newsletter|marketing|sub(scribe|scription)|warranty|protection|insurance|auto-renew/i.test(label)) {
        hits.push({
          packSlug: "dark-pattern/preselection",
          brignullId: "preselection",
          severity: "manipulative",
          matchedElement: { tag: "INPUT", text: label.slice(0, 120) }
        });
      }
    });
    if (url.includes("cart") || url.includes("product")) {
      doc.querySelectorAll(
        "input[type='checkbox'][checked][name*='protection'], input[type='checkbox'][checked][name*='warranty'], input[type='checkbox'][checked][name*='insurance']"
      ).forEach((el) => {
        hits.push({
          packSlug: "dark-pattern/sneak-into-basket",
          brignullId: "sneak-into-basket",
          severity: "deceptive",
          matchedElement: {
            tag: "INPUT",
            text: el.closest("label")?.innerText?.slice(0, 120) ?? el.getAttribute("name") ?? ""
          }
        });
      });
    }
    return hits;
  }
  var AGGREGATE_THRESHOLD = 3;
  function renderBadges(hits) {
    document.getElementById("lens-overlay")?.remove();
    document.getElementById("lens-snackbar")?.remove();
    if (hits.length === 0) return;
    const attached = [];
    for (const hit of hits) {
      const anchor = locateAnchor(hit);
      if (!anchor) continue;
      const host = attachDarkPatternBadge(anchor, hit);
      if (host) attached.push({ hit, host });
    }
    if (attached.length === 0 || hits.length > AGGREGATE_THRESHOLD) {
      renderAggregateSnackbar(hits, () => {
        window.open("https://lens-b1h.pages.dev", "_blank", "noopener,noreferrer");
      });
    }
  }
  function locateAnchor(hit) {
    const sel = hit.matchedElement.selector;
    if (sel) {
      try {
        const el = document.querySelector("." + sel.split(/\s+/).join("."));
        if (el) return el;
      } catch {
      }
    }
    const text = (hit.matchedElement.text || "").slice(0, 50).trim();
    if (!text) return null;
    const candidates = document.querySelectorAll(
      "span, div, label, td, li, p, strong, em, small"
    );
    for (const c of candidates) {
      if ((c.innerText ?? "").includes(text)) {
        return c;
      }
      if (candidates.length > 2e3) break;
    }
    return null;
  }

  // content/hosts/common.ts
  function txt(el) {
    return el?.innerText?.trim() ?? "";
  }
  function markStale(host) {
    const g = globalThis;
    g.__lens = g.__lens ?? {};
    g.__lens.stale = g.__lens.stale ?? {};
    if (g.__lens.stale[host]) return false;
    g.__lens.stale[host] = true;
    return true;
  }

  // content/hosts/chatgpt.ts
  var chatgptAdapter = {
    id: "chatgpt",
    match: (url) => url.hostname === "chatgpt.com" || url.hostname === "chat.openai.com",
    detectResponses: (root) => {
      const primary = [...root.querySelectorAll('[data-message-author-role="assistant"]')];
      if (primary.length > 0) return primary;
      const alt = [
        ...root.querySelectorAll('article[data-turn="assistant"]'),
        ...root.querySelectorAll('article[data-author-role="assistant"]')
      ];
      if (alt.length > 0) {
        if (markStale("chatgpt")) console.warn("[Lens] chatgpt selector stale \u2014 using fallback");
        return alt;
      }
      return [];
    },
    extractText: (el) => txt(el),
    responseAnchor: (el) => el,
    extractUserPrompt: (el) => {
      let n = el.previousElementSibling;
      while (n) {
        const user = n.querySelector?.('[data-message-author-role="user"]');
        if (user) return txt(user);
        if (n.matches?.('[data-message-author-role="user"]')) return txt(n);
        n = n.previousElementSibling;
      }
      const container = el.closest?.("article, div[role]");
      let p = container?.previousElementSibling ?? null;
      while (p) {
        const user = p.querySelector?.('[data-message-author-role="user"]');
        if (user) return txt(user);
        p = p.previousElementSibling;
      }
      return null;
    }
  };

  // content/hosts/claude.ts
  var claudeAdapter = {
    id: "claude",
    match: (url) => url.hostname === "claude.ai" || url.hostname.endsWith(".claude.ai"),
    detectResponses: (root) => {
      const primary = [
        ...root.querySelectorAll(".font-claude-message, .font-claude-response")
      ];
      if (primary.length > 0) return primary;
      const alt = [
        ...root.querySelectorAll('[data-testid="message-content"]'),
        ...root.querySelectorAll('[data-testid="assistant-message"]')
      ];
      if (alt.length > 0) {
        if (markStale("claude")) console.warn("[Lens] claude selector stale \u2014 using fallback");
        return alt;
      }
      return [];
    },
    extractText: (el) => txt(el),
    responseAnchor: (el) => el,
    extractUserPrompt: (el) => {
      let n = el.parentElement?.previousElementSibling ?? el.previousElementSibling;
      while (n) {
        const user = n.querySelector?.('[data-testid="user-message"]');
        if (user) return txt(user);
        n = n.previousElementSibling;
      }
      return null;
    }
  };

  // content/hosts/gemini.ts
  var geminiAdapter = {
    id: "gemini",
    match: (url) => url.hostname === "gemini.google.com",
    detectResponses: (root) => {
      const primary = [
        ...root.querySelectorAll(
          "model-response, [data-response-id], message-content"
        )
      ];
      if (primary.length > 0) return primary;
      const alt = [
        ...root.querySelectorAll('[data-test-id="conversation-model-response"]'),
        ...root.querySelectorAll('[role="region"][aria-label*="response" i]')
      ];
      if (alt.length > 0) {
        if (markStale("gemini")) console.warn("[Lens] gemini selector stale \u2014 using fallback");
        return alt;
      }
      return [];
    },
    extractText: (el) => txt(el),
    responseAnchor: (el) => el,
    extractUserPrompt: (el) => {
      let n = el.parentElement?.previousElementSibling ?? null;
      while (n) {
        const user = n.querySelector?.("user-query, [data-test-id='user-message']");
        if (user) return txt(user);
        n = n.previousElementSibling;
      }
      return null;
    }
  };

  // content/hosts/rufus.ts
  var rufusAdapter = {
    id: "rufus",
    match: (url) => url.hostname.endsWith("amazon.com"),
    detectResponses: (root) => {
      const panel = root.querySelector('[data-feature-name="rufus"]') ?? root.querySelector('[data-feature-name="amazon-shopping"]') ?? root.querySelector('[aria-label*="Rufus" i]') ?? document.querySelector('[data-feature-name="rufus"]') ?? document.querySelector('[data-feature-name="amazon-shopping"]') ?? document.querySelector('[aria-label*="Rufus" i]');
      if (!panel) return [];
      const primary = [
        ...panel.querySelectorAll(
          '[role="article"], .rufus-response, [data-testid="rufus-response"]'
        )
      ];
      if (primary.length > 0) return primary;
      const alt = [
        ...panel.querySelectorAll('[data-component-type*="rufus" i]'),
        ...panel.querySelectorAll('div[role="region"]')
      ];
      if (alt.length > 0) {
        if (markStale("rufus")) console.warn("[Lens] rufus selector stale \u2014 using fallback");
        return alt;
      }
      return [];
    },
    extractText: (el) => txt(el),
    responseAnchor: (el) => el
  };

  // content/hosts/perplexity.ts
  var perplexityAdapter = {
    id: "perplexity",
    match: (url) => url.hostname === "perplexity.ai" || url.hostname === "www.perplexity.ai",
    detectResponses: (root) => {
      const primary = [
        ...root.querySelectorAll(
          '[data-testid="answer-block"], [data-testid="copilot-answer"], .prose.dark\\:prose-invert'
        )
      ];
      if (primary.length > 0) return primary;
      const alt = [
        ...root.querySelectorAll('main [data-testid="answer"]'),
        ...root.querySelectorAll('[data-testid*="thread"] article.prose'),
        ...root.querySelectorAll("main article.prose")
      ];
      if (alt.length > 0) {
        if (markStale("perplexity")) console.warn("[Lens] perplexity selector stale \u2014 using fallback");
        return alt;
      }
      return [];
    },
    extractText: (el) => txt(el),
    responseAnchor: (el) => el
  };

  // content/hosts/registry.ts
  var ADAPTERS = [
    chatgptAdapter,
    claudeAdapter,
    geminiAdapter,
    rufusAdapter,
    perplexityAdapter
  ];
  function adapterForUrl(url = new URL(window.location.href)) {
    return ADAPTERS.find((a) => a.match(url)) ?? null;
  }

  // content/bridge.ts
  var seq = 0;
  function nextRequestId() {
    seq += 1;
    return `req_${Date.now().toString(36)}_${seq}`;
  }
  function postToSidebar(win, msg) {
    const withId = { requestId: msg.requestId ?? nextRequestId(), ...msg };
    win.postMessage(withId, "*");
  }
  function onSidebarMessage(iframe, handler) {
    const fn = (e) => {
      if (e.source !== iframe.contentWindow) return;
      if (!e.data || typeof e.data !== "object") return;
      if (typeof e.data.type !== "string") return;
      handler(e.data);
    };
    window.addEventListener("message", fn);
    return () => window.removeEventListener("message", fn);
  }

  // content/injector.ts
  var IFRAME_ID = "lens-sidebar-iframe";
  var SIDEBAR_WIDTH = "min(420px, 100vw)";
  var currentInit = null;
  var unsub = null;
  function makeIframe() {
    const iframe = document.createElement("iframe");
    iframe.id = IFRAME_ID;
    iframe.setAttribute("aria-label", "Lens sidebar");
    iframe.setAttribute("title", "Lens");
    iframe.src = chrome.runtime.getURL("sidebar/index.html");
    const prefersReduced = typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    iframe.style.cssText = `
    position: fixed; top: 0; right: 0; bottom: 0;
    width: ${SIDEBAR_WIDTH}; height: 100vh;
    border: 0; margin: 0; padding: 0;
    background: transparent; z-index: 2147483647;
    transform: translateX(100%);
    transition: ${prefersReduced ? "none" : "transform 300ms cubic-bezier(0.22, 1, 0.36, 1)"};
    box-shadow: -12px 0 48px rgba(15, 20, 30, 0.18);
    color-scheme: light;
  `;
    return iframe;
  }
  function openSidebar(init) {
    currentInit = init;
    let iframe = document.getElementById(IFRAME_ID);
    const slideIn = () => {
      if (!iframe) return;
      requestAnimationFrame(() => {
        iframe.style.transform = "translateX(0)";
      });
    };
    if (!iframe) {
      iframe = makeIframe();
      document.documentElement.append(iframe);
      unsub?.();
      unsub = onSidebarMessage(iframe, (msg) => {
        if (msg.type === "ready" && currentInit) {
          postToSidebar(iframe.contentWindow, { type: "init", payload: currentInit });
          slideIn();
        } else if (msg.type === "request-close") {
          closeSidebar();
        }
      });
    } else {
      postToSidebar(iframe.contentWindow, { type: "init", payload: init });
      slideIn();
    }
    persistState(true);
  }
  function closeSidebar() {
    const iframe = document.getElementById(IFRAME_ID);
    if (!iframe) return;
    iframe.style.transform = "translateX(100%)";
    persistState(false);
  }
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    const iframe = document.getElementById(IFRAME_ID);
    if (!iframe) return;
    if (iframe.style.transform !== "translateX(100%)") closeSidebar();
  });
  function persistState(open) {
    try {
      const origin = window.location.origin;
      const key = `lens.sidebar.v1.${origin}`;
      const state = { open, at: Date.now() };
      localStorage.setItem(key, JSON.stringify(state));
    } catch {
    }
  }

  // content/pill.ts
  var PILL_ATTR = "data-lens-pill";
  var PILL_TEMPLATE = `
<style>
  :host, button { all: initial; }
  .lens-pill {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 999px;
    background: #DA7756; color: #fff;
    font: 600 14px/1 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    cursor: pointer;
    box-shadow: 0 1px 4px rgba(15, 20, 30, 0.2);
    transform: scale(1);
    transition: transform 150ms cubic-bezier(0.22, 1, 0.36, 1),
                box-shadow 150ms ease, background 150ms ease;
    border: 1px solid rgba(0, 0, 0, 0.04);
    outline: none;
  }
  .lens-pill:hover, .lens-pill:focus-visible {
    transform: scale(1.06);
    box-shadow: 0 2px 8px rgba(15, 20, 30, 0.28);
    background: #c86a4a;
  }
  .lens-pill:focus-visible {
    box-shadow: 0 0 0 3px rgba(218, 119, 86, 0.35), 0 2px 8px rgba(15, 20, 30, 0.28);
  }
  .lens-pill:active { transform: scale(0.96); }
  @media (prefers-reduced-motion: reduce) {
    .lens-pill { transition: none; }
  }
  .lens-label {
    position: absolute; bottom: calc(100% + 6px); right: 0;
    background: #1a1a1a; color: #fafbfc;
    font: 500 11px/1.4 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    padding: 5px 9px; border-radius: 4px; white-space: nowrap;
    opacity: 0; transform: translateY(4px); pointer-events: none;
    transition: opacity 150ms ease, transform 150ms ease;
  }
  .lens-pill:hover + .lens-label,
  .lens-pill:focus-visible + .lens-label {
    opacity: 1; transform: translateY(0);
  }
  .wrap { position: relative; display: inline-block; }
</style>
<div class="wrap">
  <button type="button" class="lens-pill" aria-label="Audit this AI recommendation with Lens">\u25C9</button>
  <span class="lens-label">Audit with Lens</span>
</div>
`;
  function attachPill(responseEl, adapter) {
    if (responseEl.getAttribute(PILL_ATTR) === "1") return;
    const cs = window.getComputedStyle(responseEl);
    if (cs.position === "static") {
      responseEl.style.position = "relative";
    }
    const host = document.createElement("span");
    host.style.cssText = "position:absolute;bottom:44px;right:8px;z-index:2147483646;line-height:0;";
    host.setAttribute("data-lens", "pill-host");
    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = PILL_TEMPLATE;
    const btn = shadow.querySelector(".lens-pill");
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const text = adapter.extractText(responseEl);
      const userPrompt = adapter.extractUserPrompt?.(responseEl) ?? null;
      openSidebar({
        origin: window.location.origin,
        host: adapter.id,
        responseText: text,
        userPrompt,
        apiBase: "https://lens-api.webmarinelli.workers.dev"
      });
    });
    responseEl.append(host);
    responseEl.setAttribute(PILL_ATTR, "1");
  }

  // content/observer.ts
  function watchForResponses(adapter) {
    for (const el of adapter.detectResponses(document)) attachPill(el, adapter);
    const mo = new MutationObserver((mutations) => {
      for (const m of mutations) {
        for (const n of m.addedNodes) {
          if (!(n instanceof HTMLElement)) continue;
          const candidates = adapter.detectResponses(n).length > 0 ? adapter.detectResponses(n) : adapter.detectResponses(n.ownerDocument ?? document);
          for (const el of candidates) attachPill(el, adapter);
        }
      }
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    const reattach = () => {
      for (const el of adapter.detectResponses(document)) attachPill(el, adapter);
    };
    window.addEventListener("popstate", reattach);
    const origPush = history.pushState.bind(history);
    history.pushState = function(...args) {
      origPush(...args);
      setTimeout(reattach, 100);
    };
    return mo;
  }

  // content/consent.ts
  var KEY_PREFIX2 = "lens.consent.v1";
  function keyOf2(host) {
    return `${KEY_PREFIX2}.${host}`;
  }
  function read(host) {
    try {
      const v = typeof localStorage !== "undefined" && localStorage.getItem(keyOf2(host)) || null;
      if (v === "always" || v === "ask" || v === "never") return v;
      return null;
    } catch {
      return null;
    }
  }
  function write(host, state) {
    try {
      if (typeof localStorage !== "undefined") localStorage.setItem(keyOf2(host), state);
    } catch {
    }
  }
  function getConsent(host) {
    return read(host);
  }
  function setConsent(host, state) {
    write(host, state);
  }
  function canStage2(host) {
    return read(host) === "always";
  }
  function askForConsent(host, patternName) {
    return new Promise((resolve) => {
      const container = document.createElement("div");
      container.style.cssText = `
      position: fixed; inset: 0; z-index: 2147483647;
      background: rgba(15,20,30,0.45);
      display: flex; align-items: center; justify-content: center; padding: 16px;
      font: 14px/1.55 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    `;
      const shadow = container.attachShadow({ mode: "closed" });
      shadow.innerHTML = `
      <style>
        :host, button { all: initial; box-sizing: border-box; }
        * { box-sizing: border-box; }
        .modal {
          background: #fff; color: #1a1a1a; max-width: 440px; width: 100%;
          border-radius: 8px; border: 1px solid #e5e8ec; padding: 24px;
          box-shadow: 0 16px 48px rgba(15,20,30,0.25);
          font: 14px/1.55 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        h2 { margin: 0 0 8px; font-size: 17px; letter-spacing: -0.01em; font-weight: 700; color: #1a1a1a; }
        p { margin: 0 0 14px; color: #4a5260; font-size: 13px; }
        .host { font-family: "SF Mono", Menlo, Consolas, monospace; color: #1a1a1a; background: #f4f6f8; padding: 1px 6px; border-radius: 3px; }
        .actions { display: grid; gap: 8px; margin-top: 16px; }
        .btn {
          border: 1px solid #e5e8ec; background: #fff; color: #1a1a1a;
          padding: 10px 14px; border-radius: 6px; cursor: pointer;
          font: 500 13px/1.4 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          text-align: left; transition: background 150ms ease, border-color 150ms ease;
        }
        .btn:hover { border-color: #DA7756; background: rgba(218,119,86,0.06); }
        .btn.primary { background: #DA7756; color: #fff; border-color: #DA7756; }
        .btn.primary:hover { background: #c86a4a; }
        .btn.muted { color: #6a7488; }
        .btn .sub { color: #6a7488; font-weight: 400; display: block; margin-top: 2px; font-size: 12px; }
        .btn.primary .sub { color: rgba(255,255,255,0.82); }
      </style>
      <div class="modal" role="dialog" aria-modal="true" aria-labelledby="lens-consent-title">
        <h2 id="lens-consent-title">Lens spotted something on <span class="host">HOST</span></h2>
        <p>It looks like a <strong>PATTERN</strong> pattern. To confirm, Lens can send a short excerpt (~200 characters) of the matched element to its API for verification. Your choice is remembered for this host only.</p>
        <div class="actions">
          <button type="button" class="btn primary" data-val="always">
            Always allow on HOST
            <span class="sub">Recommended if you trust Lens to audit this site.</span>
          </button>
          <button type="button" class="btn" data-val="ask">
            Ask each time
            <span class="sub">Default. You'll see this prompt on future detections.</span>
          </button>
          <button type="button" class="btn muted" data-val="never">
            Never send from HOST
            <span class="sub">Lens will skip Stage-2 verification on this host.</span>
          </button>
        </div>
      </div>
    `;
      shadow.querySelectorAll(".host, #lens-consent-title .host").forEach((el) => {
        el.textContent = host;
      });
      shadow.querySelector("p strong").textContent = patternName;
      shadow.querySelectorAll(".btn").forEach((btn) => {
        const txt2 = btn.firstChild;
        if (txt2 && txt2.textContent) txt2.textContent = txt2.textContent.replace("HOST", host);
      });
      shadow.querySelectorAll("[data-val]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const val = btn.getAttribute("data-val");
          setConsent(host, val);
          container.remove();
          resolve(val);
        });
      });
      document.body.append(container);
      const onKey = (e) => {
        if (e.key === "Escape") {
          document.removeEventListener("keydown", onKey);
          container.remove();
          resolve("ask");
        }
      };
      document.addEventListener("keydown", onKey);
    });
  }

  // content/retail/detect-product-page.ts
  function detectHost(url = new URL(window.location.href)) {
    const h = url.hostname.toLowerCase();
    if (h.endsWith("amazon.com") || h === "amazon.com") return "amazon";
    if (h.endsWith("bestbuy.com")) return "bestbuy";
    if (h.endsWith("walmart.com")) return "walmart";
    if (h.endsWith("target.com")) return "target";
    if (h.endsWith("homedepot.com")) return "homedepot";
    if (h.endsWith("costco.com")) return "costco";
    return null;
  }
  function isProductPage(url = new URL(window.location.href)) {
    const host = detectHost(url);
    if (!host) return false;
    const p = url.pathname;
    switch (host) {
      case "amazon":
        return /\/(dp|gp\/product)\/[A-Z0-9]{10}\b/i.test(p);
      case "bestbuy":
        return /\/site\/.+\.p\?/i.test(p + url.search) || /\/site\/.+\/\d+\.p\b/i.test(p);
      case "walmart":
        return /^\/ip\/.+\/\d+/.test(p);
      case "target":
        return /^\/p\/.+\/A-\d+/.test(p);
      case "homedepot":
        return /\/p\/.+\/\d{9,}/.test(p);
      case "costco":
        return /\/product\..*\.html/i.test(p) || /\.product\..*\.html/i.test(p);
      default:
        return false;
    }
  }
  function extractProductId(host, url = new URL(window.location.href)) {
    if (host === "amazon") {
      const m = url.pathname.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})\b/i);
      return m?.[1]?.toUpperCase() ?? null;
    }
    if (host === "bestbuy") {
      const m = url.pathname.match(/\/(\d{7,})\.p\b/);
      return m?.[1] ?? null;
    }
    if (host === "walmart") {
      const m = url.pathname.match(/\/ip\/[^/]+\/(\d+)\b/);
      return m?.[1] ?? null;
    }
    if (host === "target") {
      const m = url.pathname.match(/\/A-(\d+)\b/);
      return m?.[1] ?? null;
    }
    if (host === "homedepot") {
      const m = url.pathname.match(/\/p\/[^/]+\/(\d{9,})/);
      return m?.[1] ?? null;
    }
    return null;
  }
  function parsePriceString(raw) {
    if (!raw) return null;
    const cleaned = raw.replace(/,/g, "").trim();
    const m = cleaned.match(/\$?(\d+(?:\.\d+)?)/);
    if (!m || !m[1]) return null;
    const n = Number.parseFloat(m[1]);
    return Number.isFinite(n) && n > 0 ? n : null;
  }
  function extractPrice(host, root = document) {
    const find = (sel) => root.querySelector(sel);
    let raw = null;
    switch (host) {
      case "amazon": {
        raw = find("#corePriceDisplay_desktop_feature_div .a-offscreen")?.innerText ?? find("#apex_desktop .a-offscreen")?.innerText ?? find(".a-price .a-offscreen")?.innerText ?? find("#priceblock_ourprice")?.innerText ?? find("#priceblock_saleprice")?.innerText ?? null;
        if (!raw) {
          const whole = find(".a-price-whole")?.innerText;
          const frac = find(".a-price-fraction")?.innerText;
          if (whole) raw = `$${whole}.${frac ?? "00"}`;
        }
        break;
      }
      case "bestbuy":
        raw = find('.priceView-hero-price .priceView-customer-price span[aria-hidden="true"]')?.innerText ?? find(".priceView-customer-price > span")?.innerText ?? null;
        break;
      case "walmart":
        raw = find('[data-automation-id="product-price"]')?.innerText ?? find('[itemprop="price"]')?.getAttribute("content") ?? null;
        break;
      case "target":
        raw = find('[data-test="product-price"]')?.innerText ?? find('[data-test="current-price"]')?.innerText ?? null;
        break;
      case "homedepot":
        raw = find('[data-testid="mainPrice"]')?.innerText ?? find(".price-format__main-price")?.innerText ?? null;
        break;
      case "costco":
        raw = find('[data-testid="pricing"]')?.innerText ?? find("#pull-right-price")?.innerText ?? null;
        break;
    }
    return parsePriceString(raw);
  }
  function detectProductPage() {
    const url = new URL(window.location.href);
    if (!isProductPage(url)) return null;
    const host = detectHost(url);
    const productId = extractProductId(host, url);
    const currentPrice = extractPrice(host, document);
    return {
      host,
      url: url.origin + url.pathname,
      productId,
      currentPrice,
      currency: "USD"
    };
  }

  // content/retail/price-history-badge.ts
  var API_BASE = "https://lens-api.webmarinelli.workers.dev";
  var BADGE_ATTR2 = "data-lens-price-badge";
  var CACHE = /* @__PURE__ */ new Map();
  var BADGED_ANCHORS = /* @__PURE__ */ new WeakSet();
  function stripRefFromPath(url) {
    try {
      const u = new URL(url);
      u.pathname = u.pathname.replace(/\/ref=[^/]+/gi, "");
      u.search = "";
      u.hash = "";
      return u.toString();
    } catch {
      return url;
    }
  }
  var VERDICT_UI = {
    "genuine-sale": { color: "#247a50", bg: "#ecfaf2", border: "#3fb27f", icon: "\u2713", label: "Genuine sale" },
    "fake-sale": { color: "#8a2f2f", bg: "#fdecec", border: "#d85a5a", icon: "\u26A0", label: "Fake sale" },
    "modest-dip": { color: "#9c6b14", bg: "#fdf5e6", border: "#c78a1f", icon: "\u2193", label: "Modest dip" },
    "no-sale": { color: "#555", bg: "#f5f6f7", border: "#c7cfd6", icon: "\xB7", label: "No sale" },
    "insufficient-data": { color: "#777", bg: "#f5f6f7", border: "#d1d5d9", icon: "?", label: "No price history" }
  };
  function cacheKey(meta) {
    const id = meta.productId ?? meta.url;
    return `${meta.host}::${id}::${meta.currentPrice ?? ""}`;
  }
  async function fetchVerdict(meta) {
    const key = cacheKey(meta);
    const cached = CACHE.get(key);
    if (cached) return cached;
    if (meta.currentPrice === null) return null;
    try {
      const cleanUrl = stripRefFromPath(meta.url);
      const params = new URLSearchParams({ url: cleanUrl });
      const res = await fetch(`${API_BASE}/price-history?${params.toString()}`, {
        method: "GET",
        headers: { "accept": "application/json" }
      });
      if (!res.ok) return null;
      const body = await res.json();
      const verdict = {
        verdict: body.saleVerdict,
        explanation: body.saleExplanation,
        ...body.discountActual !== void 0 ? { discountActual: body.discountActual } : {},
        ...body.discountClaimed !== void 0 ? { discountClaimed: body.discountClaimed } : {}
      };
      CACHE.set(key, verdict);
      return verdict;
    } catch (err) {
      console.warn("[Lens] price-history fetch failed:", err.message);
      return null;
    }
  }
  function priceAnchor(host) {
    const sel = {
      amazon: "#corePriceDisplay_desktop_feature_div, #apex_desktop, #priceblock_ourprice, .a-price",
      bestbuy: ".priceView-hero-price",
      walmart: '[data-automation-id="product-price"]',
      target: '[data-test="product-price"]',
      homedepot: '[data-testid="mainPrice"]',
      costco: '[data-testid="pricing"], #pull-right-price'
    }[host];
    return document.querySelector(sel);
  }
  function renderBadge(verdict, anchor) {
    if (anchor.hasAttribute(BADGE_ATTR2)) return null;
    if (BADGED_ANCHORS.has(anchor)) return null;
    if (anchor.nextElementSibling?.getAttribute("data-lens") === "price-badge-host") return null;
    if (verdict.verdict === "no-sale") {
      anchor.setAttribute(BADGE_ATTR2, "1");
      return null;
    }
    const ui = VERDICT_UI[verdict.verdict];
    const host = document.createElement("span");
    host.setAttribute("data-lens", "price-badge-host");
    host.style.cssText = "display:inline-block;margin:8px 0 0 0;line-height:0;";
    const shadow = host.attachShadow({ mode: "closed" });
    const delta = verdict.discountActual !== void 0 ? `${verdict.discountActual.toFixed(1)}% vs 90-day median` : "";
    const claimed = verdict.discountClaimed !== void 0 ? ` (claimed ${verdict.discountClaimed.toFixed(0)}%)` : "";
    shadow.innerHTML = `
    <style>
      :host, button { all: initial; }
      .lens-pbadge {
        display: inline-flex; align-items: center; gap: 6px;
        background: ${ui.bg}; color: ${ui.color};
        border: 1px solid ${ui.border}; border-radius: 6px;
        padding: 5px 10px;
        font: 600 12px/1.3 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        cursor: pointer;
        box-shadow: 0 1px 2px rgba(15,20,30,0.04);
      }
      .lens-pbadge:hover { filter: brightness(0.98); }
      .lens-pbadge:focus-visible {
        outline: 2px solid #DA7756; outline-offset: 2px;
      }
      .icon { font-size: 14px; line-height: 1; }
      .label { font-weight: 700; }
      .detail { font-weight: 500; color: ${ui.color}; opacity: 0.85; }
    </style>
    <button type="button" class="lens-pbadge" role="status" aria-live="polite"
            aria-label="Lens price-history: ${ui.label}. ${delta}${claimed}">
      <span class="icon" aria-hidden="true">${ui.icon}</span>
      <span class="label">${ui.label}</span>
      ${delta ? `<span class="detail">\xB7 ${delta}${claimed}</span>` : ""}
    </button>
  `;
    const btn = shadow.querySelector(".lens-pbadge");
    btn.addEventListener("click", () => {
      console.log("[Lens] price-badge click", verdict);
    });
    anchor.insertAdjacentElement("afterend", host);
    anchor.setAttribute(BADGE_ATTR2, "1");
    BADGED_ANCHORS.add(anchor);
    return host;
  }
  async function bootPriceHistory() {
    const meta = detectProductPage();
    if (!meta) return;
    if (meta.currentPrice === null) {
      console.log("[Lens] price-history: no price detected on", meta.host);
      return;
    }
    const anchor = priceAnchor(meta.host);
    if (!anchor) {
      console.log("[Lens] price-history: no anchor element on", meta.host);
      return;
    }
    const hostName = location.host;
    if (getConsent(hostName) === "never") return;
    if (!canStage2(hostName)) return;
    const verdict = await fetchVerdict(meta);
    if (!verdict) return;
    renderBadge(verdict, anchor);
  }

  // content/retail/cart-summary-badge.ts
  var API_BASE2 = "https://lens-api.webmarinelli.workers.dev";
  var BADGE_ATTR3 = "data-lens-cart-summary";
  var BADGED_ANCHORS2 = /* @__PURE__ */ new WeakSet();
  var VERDICT_UI2 = {
    proceed: { color: "#247a50", bg: "#ecfaf2", border: "#3fb27f", icon: "\u2713", label: "Proceed" },
    hesitate: { color: "#9c6b14", bg: "#fdf5e6", border: "#c78a1f", icon: "\u26A0", label: "Hesitate" },
    rethink: { color: "#8a2f2f", bg: "#fdecec", border: "#d85a5a", icon: "\u2717", label: "Rethink" }
  };
  function isCartOrCheckout(url = new URL(window.location.href)) {
    const p = url.pathname.toLowerCase();
    return p.includes("/cart") || p.includes("/checkout") || p.includes("/basket") || p.includes("/booking/confirm") || p.includes("/payment");
  }
  function cartTotalAnchor(host) {
    const find = (sel) => document.querySelector(sel);
    switch (host) {
      case "amazon":
        return find("#sc-subtotal-amount-buybox") ?? find("#sc-subtotal-amount-activecart") ?? find('[data-name="Subtotal"] .a-price .a-offscreen') ?? find(".ewc-subtotal .a-price") ?? null;
      case "bestbuy":
        return find('[data-testid="order-summary-subtotal-value"]') ?? find(".order-summary__total") ?? null;
      case "walmart":
        return find('[data-testid="order-summary-sub-total"]') ?? find('[data-automation-id="sub-total"]') ?? null;
      case "target":
        return find('[data-test="order-summary-subtotal"]') ?? find('[data-test="cart-summary-sub-total"]') ?? null;
      case "homedepot":
        return find(".price-detailed__total") ?? find('[data-automation="price-format"]') ?? null;
      case "costco":
        return find('[data-automation-id="orderSummarySubtotal"]') ?? null;
      default:
        return null;
    }
  }
  async function postCheckoutSummary(host, passiveScan) {
    try {
      const res = await fetch(`${API_BASE2}/checkout/summary`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          host,
          signals: { passiveScan }
        })
      });
      if (!res.ok) return null;
      return await res.json();
    } catch (err) {
      console.warn("[Lens] checkout-summary fetch failed:", err.message);
      return null;
    }
  }
  function renderVerdictBadge(resp, anchor) {
    if (anchor.hasAttribute(BADGE_ATTR3)) return null;
    if (BADGED_ANCHORS2.has(anchor)) return null;
    if (anchor.nextElementSibling?.getAttribute("data-lens") === "cart-summary-host") return null;
    if (document.querySelector('[data-lens="cart-summary-host"]')) return null;
    if (resp.verdict === "proceed" && resp.signalCount === 0) {
      anchor.setAttribute(BADGE_ATTR3, "1");
      BADGED_ANCHORS2.add(anchor);
      return null;
    }
    const ui = VERDICT_UI2[resp.verdict];
    const topRationale = resp.rationale[0];
    const topMsg = topRationale ? topRationale.message : resp.recommendation;
    const host = document.createElement("div");
    host.setAttribute("data-lens", "cart-summary-host");
    host.style.cssText = "margin:12px 0;line-height:0;";
    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = `
    <style>
      :host, button, details, summary { all: initial; }
      .wrap {
        display: block;
        background: ${ui.bg}; color: ${ui.color};
        border: 1px solid ${ui.border}; border-radius: 8px;
        padding: 10px 12px;
        font: 500 13px/1.4 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        line-height: 1.4;
      }
      .head { display: flex; align-items: center; gap: 8px; font-weight: 700; cursor: pointer; }
      .head:focus-visible { outline: 2px solid #DA7756; outline-offset: 2px; }
      .icon { font-size: 15px; line-height: 1; }
      .label { font-weight: 700; letter-spacing: 0.02em; }
      .score { margin-left: auto; font-family: "SF Mono", Menlo, Consolas, monospace; font-size: 12px; font-weight: 500; opacity: 0.8; }
      .top-msg { margin-top: 4px; font-weight: 500; opacity: 0.92; }
      .details { margin-top: 10px; border-top: 1px solid ${ui.border}30; padding-top: 10px; display: none; }
      .details.open { display: block; }
      .details ul { margin: 0; padding: 0 0 0 18px; font-weight: 500; font-size: 12px; }
      .details li { margin: 3px 0; color: ${ui.color}; }
    </style>
    <section class="wrap" role="status" aria-live="polite" aria-label="Lens checkout verdict: ${ui.label}. ${topMsg}">
      <button type="button" class="head" aria-expanded="false">
        <span class="icon" aria-hidden="true">${ui.icon}</span>
        <span class="label">Lens: ${ui.label.toLowerCase()}</span>
        <span class="score">${resp.score}/100</span>
      </button>
      <div class="top-msg">${topMsg.replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
    )}</div>
      ${resp.rationale.length > 1 ? `<div class="details">
             <ul>${resp.rationale.slice(0, 3).map((r) => `<li>${r.message.replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
    )}</li>`).join("")}</ul>
           </div>` : ""}
    </section>
  `;
    const head = shadow.querySelector(".head");
    const details = shadow.querySelector(".details");
    head.addEventListener("click", () => {
      if (!details) return;
      const open = details.classList.toggle("open");
      head.setAttribute("aria-expanded", open ? "true" : "false");
    });
    const parent = anchor.parentElement ?? anchor;
    parent.insertAdjacentElement("afterend", host);
    anchor.setAttribute(BADGE_ATTR3, "1");
    BADGED_ANCHORS2.add(anchor);
    return host;
  }
  async function bootCheckoutSummary(passiveScan) {
    if (!isCartOrCheckout()) return;
    const host = detectHost();
    if (!host) return;
    const hostName = location.host;
    if (getConsent(hostName) === "never") return;
    if (!canStage2(hostName)) return;
    const anchor = cartTotalAnchor(host);
    if (!anchor) {
      console.log("[Lens] cart-summary: no cart-total anchor on", host);
      return;
    }
    const resp = await postCheckoutSummary(hostName, passiveScan);
    if (!resp) return;
    renderVerdictBadge(resp, anchor);
  }

  // content/retail/review-scan-badge.ts
  var API_BASE3 = "https://lens-api.webmarinelli.workers.dev";
  var BADGE_ATTR4 = "data-lens-review-scan";
  var BADGED_ANCHORS3 = /* @__PURE__ */ new WeakSet();
  var SCAN_CACHE = /* @__PURE__ */ new Map();
  var SCAN_TTL_MS = 10 * 60 * 1e3;
  var inFlight = false;
  var BAND_UI = {
    clean: { color: "#247a50", bg: "#ecfaf2", border: "#3fb27f", icon: "\u2713", label: "Reviews look authentic" },
    mixed: { color: "#9c6b14", bg: "#fdf5e6", border: "#c78a1f", icon: "\u26A0", label: "Mixed review signals" },
    suspect: { color: "#8a2f2f", bg: "#fdecec", border: "#d85a5a", icon: "\u2717", label: "Reviews look suspect" }
  };
  function isAmazonReviewContext(url = new URL(window.location.href)) {
    const host = url.hostname.toLowerCase();
    if (!host.includes("amazon.")) return false;
    const p = url.pathname.toLowerCase();
    return /\/dp\/[a-z0-9]{8,12}/i.test(p) || /\/gp\/product\/[a-z0-9]{8,12}/i.test(p) || p.includes("/product-reviews/");
  }
  function parseRating(text) {
    if (!text) return void 0;
    const m = text.match(/([0-5](?:\.\d)?)\s*out of\s*5/i);
    if (m) return Number(m[1]);
    const n = text.match(/^\s*([0-5](?:\.\d)?)\s*$/);
    if (n) return Number(n[1]);
    return void 0;
  }
  function parseReviewDate(text) {
    if (!text) return void 0;
    const us = text.match(/on\s+([A-Za-z]+\s+\d{1,2},\s*\d{4})/);
    if (us) {
      const d = new Date(us[1]);
      if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
    }
    const uk = text.match(/on\s+(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/);
    if (uk) {
      const d = /* @__PURE__ */ new Date(`${uk[2]} ${uk[1]}, ${uk[3]}`);
      if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
    }
    return void 0;
  }
  function extractAsin(url = location.href) {
    const m = url.match(/\/(?:dp|gp\/product|product-reviews)\/([A-Z0-9]{8,12})/i);
    return m ? m[1].toUpperCase() : null;
  }
  function scrapeVisibleReviews(doc = document) {
    const wrappers = doc.querySelectorAll('[data-hook="review"]');
    const out = [];
    for (const el of Array.from(wrappers)) {
      const bodyEl = el.querySelector('[data-hook="review-body"] span:not(.a-color-base)') ?? el.querySelector('[data-hook="review-body"]');
      const text = (bodyEl?.innerText ?? bodyEl?.textContent ?? "").trim();
      if (!text || text.length < 8) continue;
      const ratingEl = el.querySelector('[data-hook="review-star-rating"]') ?? el.querySelector('[data-hook="cmps-review-star-rating"]');
      const dateEl = el.querySelector('[data-hook="review-date"]');
      const reviewerEl = el.querySelector('[data-hook="genome-widget"] .a-profile-name') ?? el.querySelector(".a-profile-name");
      const entry = { text };
      const rating = parseRating(ratingEl?.innerText ?? ratingEl?.textContent);
      if (rating !== void 0) entry.rating = rating;
      const date = parseReviewDate(dateEl?.innerText ?? dateEl?.textContent);
      if (date !== void 0) entry.date = date;
      const reviewer = (reviewerEl?.innerText ?? reviewerEl?.textContent ?? "").trim();
      if (reviewer) entry.reviewer = reviewer;
      out.push(entry);
    }
    return out;
  }
  function reviewAnchor(doc = document) {
    return doc.querySelector("#cm-cr-dp-review-list") ?? doc.querySelector("#cm_cr-review_list") ?? doc.querySelector("#reviews-medley-footer") ?? doc.querySelector("#customerReviews") ?? null;
  }
  function extractProductName(doc = document) {
    const el = doc.querySelector("#productTitle");
    const t = (el?.innerText ?? el?.textContent ?? "").trim();
    return t || void 0;
  }
  async function postReviewScan(reviews, productName) {
    if (reviews.length < 2) return null;
    const sanitized = reviews.map((r) => {
      const out = { text: r.text };
      if (r.rating !== void 0) out.rating = r.rating;
      if (r.date !== void 0) out.date = r.date;
      return out;
    });
    try {
      const res = await fetch(`${API_BASE3}/review-scan`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ reviews: sanitized, ...productName ? { productName } : {} })
      });
      if (!res.ok) return null;
      return await res.json();
    } catch (err) {
      console.warn("[Lens] review-scan fetch failed:", err.message);
      return null;
    }
  }
  function bandFor(score) {
    if (score >= 0.7) return "clean";
    if (score >= 0.4) return "mixed";
    return "suspect";
  }
  function escapeHtml2(s) {
    return s.replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
    );
  }
  function renderBanner(result, anchor, reviewCount) {
    if (anchor.hasAttribute(BADGE_ATTR4)) return null;
    if (BADGED_ANCHORS3.has(anchor)) return null;
    if (document.querySelector('[data-lens="review-scan-host"]')) return null;
    const band = bandFor(result.authenticityScore);
    const ui = BAND_UI[band];
    if (band === "clean" && result.signalsFound.length === 0) {
      anchor.setAttribute(BADGE_ATTR4, "1");
      BADGED_ANCHORS3.add(anchor);
      return null;
    }
    const flaggedCount = result.flaggedReviewIndices.length;
    const top2 = result.signalsFound.slice(0, 2);
    const pct = Math.round(result.authenticityScore * 100);
    const headline = band === "suspect" ? `Likely incentivized \u2014 ${flaggedCount} of ${reviewCount} reviews suspect` : band === "mixed" ? flaggedCount > 0 ? `${flaggedCount} of ${reviewCount} reviews flagged` : `Mixed review signals (${pct}% authentic)` : `Reviews look authentic (${pct}%)`;
    const host = document.createElement("div");
    host.setAttribute("data-lens", "review-scan-host");
    host.style.cssText = "margin:12px 0;line-height:0;";
    const shadow = host.attachShadow({ mode: "closed" });
    const signalsHtml = top2.map((s) => `<li>${escapeHtml2(s)}</li>`).join("");
    const showScore = band !== "suspect";
    shadow.innerHTML = `
    <style>
      :host, button, section, ul, li, div, span { all: initial; }
      * { box-sizing: border-box; }
      .wrap {
        display: block;
        background: ${ui.bg}; color: ${ui.color};
        border: 1px solid ${ui.border}; border-radius: 8px;
        padding: ${band === "clean" ? "8px 12px" : "12px 14px"};
        font: 500 13px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      }
      .head { display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 700; width: 100%; text-align: left; }
      .head:focus-visible { outline: 2px solid #DA7756; outline-offset: 2px; border-radius: 4px; }
      .icon { font-size: 15px; line-height: 1; }
      .label { font-weight: 700; letter-spacing: 0.01em; }
      .score { margin-left: auto; font-family: "SF Mono", Menlo, Consolas, monospace; font-size: 12px; font-weight: 500; opacity: 0.82; }
      .status-sr { position: absolute; left: -10000px; width: 1px; height: 1px; overflow: hidden; }
      .details { margin-top: 10px; padding-top: 10px; border-top: 1px solid ${ui.border}40; display: none; }
      .details.open { display: block; }
      .details ul { margin: 0; padding: 0 0 0 18px; font-size: 12px; font-weight: 500; }
      .details li { margin: 3px 0; color: ${ui.color}; list-style: disc; }
      .caveat { margin-top: 8px; font-size: 11px; font-weight: 500; color: ${ui.color}; opacity: 0.85; }
    </style>
    <section class="wrap">
      <span class="status-sr" role="status" aria-live="polite">Lens review authenticity: ${escapeHtml2(ui.label)}. ${escapeHtml2(headline)}</span>
      <button type="button" class="head" aria-expanded="false" aria-label="${escapeHtml2(headline)}. Expand for details.">
        <span class="icon" aria-hidden="true">${ui.icon}</span>
        <span class="label">Lens: ${escapeHtml2(headline)}</span>
        ${showScore ? `<span class="score" aria-hidden="true">${pct}/100</span>` : ""}
      </button>
      ${top2.length > 0 ? `<div class="details">
             <ul>${signalsHtml}</ul>
             <div class="caveat">Scanned ${reviewCount} visible review${reviewCount === 1 ? "" : "s"}. Heuristic \u2014 seek independent reviews before purchase.</div>
           </div>` : ""}
    </section>
  `;
    const head = shadow.querySelector(".head");
    const details = shadow.querySelector(".details");
    head.addEventListener("click", () => {
      if (!details) return;
      const open = details.classList.toggle("open");
      head.setAttribute("aria-expanded", open ? "true" : "false");
    });
    anchor.insertAdjacentElement("beforebegin", host);
    anchor.setAttribute(BADGE_ATTR4, "1");
    BADGED_ANCHORS3.add(anchor);
    return host;
  }
  async function bootReviewScan() {
    if (!isAmazonReviewContext()) return;
    if (inFlight) return;
    const hostName = location.host;
    if (getConsent(hostName) === "never") return;
    if (!canStage2(hostName)) return;
    const anchor = reviewAnchor();
    if (!anchor) {
      console.log("[Lens] review-scan: no review anchor on", hostName);
      return;
    }
    const asin = extractAsin();
    if (asin) {
      const cached = SCAN_CACHE.get(asin);
      if (cached && Date.now() - cached.at < SCAN_TTL_MS) {
        renderBanner(cached.result, anchor, cached.reviewCount);
        return;
      }
    }
    const reviews = scrapeVisibleReviews();
    if (reviews.length < 2) {
      console.log("[Lens] review-scan: fewer than 2 reviews visible");
      return;
    }
    const productName = extractProductName();
    inFlight = true;
    try {
      const result = await postReviewScan(reviews, productName);
      if (!result) return;
      if (asin) SCAN_CACHE.set(asin, { result, reviewCount: reviews.length, at: Date.now() });
      renderBanner(result, anchor, reviews.length);
    } finally {
      inFlight = false;
    }
  }

  // content/retail/counterfeit-badge.ts
  var API_BASE4 = "https://lens-api.webmarinelli.workers.dev";
  var BADGE_ATTR5 = "data-lens-counterfeit";
  var BADGED_ANCHORS4 = /* @__PURE__ */ new WeakSet();
  var SCAN_TTL_MS2 = 10 * 60 * 1e3;
  var SCAN_CACHE2 = /* @__PURE__ */ new Map();
  var inFlight2 = false;
  var BAND_UI2 = {
    authentic: { color: "#247a50", bg: "#ecfaf2", border: "#3fb27f", icon: "\u2713", label: "Authentic \u2014 verified" },
    monitor: { color: "#9c6b14", bg: "#fdf5e6", border: "#c78a1f", icon: "\u26A0", label: "Counterfeit risk \u2014 monitor" },
    counterfeit: { color: "#8a2f2f", bg: "#fdecec", border: "#d85a5a", icon: "\u2717", label: "Likely counterfeit" }
  };
  function detectMarketplace(url = new URL(window.location.href)) {
    const host = url.hostname.toLowerCase();
    const p = url.pathname;
    if (host.includes("ebay.") && /\/itm\//.test(p)) return "ebay";
    if (host.includes("amazon.") && (/\/sp\b/.test(p) || url.searchParams.has("m") || url.searchParams.has("seller") || url.searchParams.has("smid"))) {
      return "amazon-3p";
    }
    if (host.includes("facebook.com") && /\/marketplace\/item\//.test(p)) return "fb-marketplace";
    if (host.includes("walmart.com") && (/\/seller\//.test(p) || url.searchParams.has("sellerId"))) return "walmart-3p";
    if (host.includes("mercari.com") && /\/item\//.test(p)) return "mercari";
    return null;
  }
  function parsePriceString2(s) {
    if (!s) return void 0;
    const m = s.match(/\$\s*([\d,]+(?:\.\d+)?)/);
    if (!m || !m[1]) return void 0;
    const n = Number(m[1].replace(/,/g, ""));
    return Number.isFinite(n) && n > 0 ? n : void 0;
  }
  function parseIntSafe(s) {
    if (!s) return void 0;
    const m = s.match(/([\d,]+)/);
    if (!m || !m[1]) return void 0;
    const n = parseInt(m[1].replace(/,/g, ""), 10);
    return Number.isFinite(n) && n >= 0 ? n : void 0;
  }
  function scrapeListing(marketplace, doc = document) {
    const host = location.hostname;
    switch (marketplace) {
      case "ebay": {
        const titleEl = doc.querySelector(".x-item-title .ux-textspans") ?? doc.querySelector("h1.x-item-title") ?? doc.querySelector("#itemTitle");
        const priceEl = doc.querySelector(".x-price-primary .ux-textspans") ?? doc.querySelector("#prcIsum") ?? doc.querySelector(".x-bin-price__content");
        const feedbackEl = doc.querySelector('[data-testid="ux-seller-section__item--feedback-count"]') ?? doc.querySelector(".x-sellercard-atf__info__about-seller .ux-seller-section__item--feedback-count");
        const out = { host, marketplace };
        const title = (titleEl?.innerText ?? titleEl?.textContent ?? "").trim();
        if (title) out.productName = title;
        const price = parsePriceString2(priceEl?.innerText ?? priceEl?.textContent);
        if (price !== void 0) out.price = price;
        const feedback = parseIntSafe(feedbackEl?.innerText ?? feedbackEl?.textContent);
        if (feedback !== void 0) out.feedbackCount = feedback;
        return out;
      }
      case "amazon-3p": {
        const titleEl = doc.querySelector("#productTitle");
        const priceEl = doc.querySelector("#corePriceDisplay_desktop_feature_div .a-offscreen") ?? doc.querySelector(".a-price .a-offscreen");
        const feedbackEl = doc.querySelector("#feedback-summary-table .feedback-link") ?? doc.querySelector(".ceb-atf-seller-rating-count");
        const sinceEl = doc.querySelector("#from");
        const out = { host, marketplace };
        const title = (titleEl?.innerText ?? titleEl?.textContent ?? "").trim();
        if (title) out.productName = title;
        const price = parsePriceString2(priceEl?.innerText ?? priceEl?.textContent);
        if (price !== void 0) out.price = price;
        const feedback = parseIntSafe(feedbackEl?.innerText ?? feedbackEl?.textContent);
        if (feedback !== void 0) out.feedbackCount = feedback;
        const since = sinceEl?.innerText ?? sinceEl?.textContent;
        if (since) {
          const age = parseSinceToDays(since);
          if (age !== void 0) out.sellerAgeDays = age;
        }
        const isSellerStorefront = location.pathname.includes("/sp") || location.pathname.includes("/seller/");
        const rows = isSellerStorefront ? doc.querySelectorAll(".a-histogram-row") : [];
        const histo = {
          star1: 0,
          star2: 0,
          star3: 0,
          star4: 0,
          star5: 0
        };
        let anyRow = false;
        for (const row of Array.from(rows)) {
          const rating = row.getAttribute("data-rating");
          const countEl = row.querySelector(".a-text-right");
          const count = parseIntSafe(countEl?.innerText ?? countEl?.textContent);
          if (rating && count !== void 0 && count >= 0) {
            const key = `star${rating}`;
            if (key in histo) {
              histo[key] = count;
              anyRow = true;
            }
          }
        }
        if (anyRow) out.feedbackDistribution = histo;
        return out;
      }
      case "fb-marketplace": {
        const main = doc.querySelector('div[role="main"]');
        if (!main) return { host, marketplace };
        const titleEl = main.querySelector('h1[role="heading"]') ?? main.querySelector("h1");
        const out = { host, marketplace };
        const title = (titleEl?.innerText ?? titleEl?.textContent ?? "").trim();
        if (title) out.productName = title;
        const candidates = [
          ...Array.from(main.querySelectorAll('span[dir="auto"]')),
          ...Array.from(main.querySelectorAll("span"))
        ];
        for (const el of candidates) {
          const t = (el.innerText ?? el.textContent ?? "").trim();
          if (/^\$[\d,]+(?:\.\d+)?$/.test(t)) {
            const p = parsePriceString2(t);
            if (p !== void 0) {
              out.price = p;
              break;
            }
          }
        }
        return out;
      }
      case "walmart-3p": {
        const titleEl = doc.querySelector('[itemprop="name"]') ?? doc.querySelector("h1");
        const priceEl = doc.querySelector('[data-automation-id="product-price"]');
        const feedbackEl = doc.querySelector('[data-automation-id="rating-count"]');
        const out = { host, marketplace };
        const title = (titleEl?.innerText ?? titleEl?.textContent ?? "").trim();
        if (title) out.productName = title;
        const price = parsePriceString2(priceEl?.innerText ?? priceEl?.textContent);
        if (price !== void 0) out.price = price;
        const feedback = parseIntSafe(feedbackEl?.innerText ?? feedbackEl?.textContent);
        if (feedback !== void 0) out.feedbackCount = feedback;
        try {
          const sellerId = new URL(location.href).searchParams.get("sellerId");
          if (sellerId) out.sellerId = sellerId;
        } catch {
        }
        return out;
      }
      case "mercari": {
        const titleEl = doc.querySelector('[data-testid="ItemDetailsTitle"]') ?? doc.querySelector("h1");
        const priceEl = doc.querySelector('[data-testid="ItemDetailsPrice"]');
        const feedbackEl = doc.querySelector('[data-testid="ItemDetailsSellerRatings"]');
        const out = { host, marketplace };
        const title = (titleEl?.innerText ?? titleEl?.textContent ?? "").trim();
        if (title) out.productName = title;
        const price = parsePriceString2(priceEl?.innerText ?? priceEl?.textContent);
        if (price !== void 0) out.price = price;
        const feedback = parseIntSafe(feedbackEl?.innerText ?? feedbackEl?.textContent);
        if (feedback !== void 0) out.feedbackCount = feedback;
        return out;
      }
      default:
        return null;
    }
  }
  function parseSinceToDays(text) {
    const m = text.match(/since\s+([A-Za-z]+)\s+(\d{4})/i);
    if (!m) return void 0;
    const d = /* @__PURE__ */ new Date(`${m[1]} 1, ${m[2]}`);
    if (isNaN(d.getTime())) return void 0;
    return Math.max(0, Math.floor((Date.now() - d.getTime()) / 864e5));
  }
  var CATEGORY_KEYWORDS = [
    { kw: /\b(espresso|coffee\s+maker|coffee\s+machine)\b/i, cat: "espresso-machine" },
    { kw: /\b(macbook|laptop|thinkpad|notebook\s+pc)\b/i, cat: "laptop" },
    { kw: /\b(iphone|galaxy|pixel|smartphone)\b/i, cat: "smartphone" },
    { kw: /\b(headphone|earbud|airpod|earphone|noise[\s-]?cancel)/i, cat: "headphones" },
    { kw: /\b(apple\s+watch|garmin|rolex|watch)\b/i, cat: "watch" },
    { kw: /\b(camera|canon\s+eos|sony\s+alpha|nikon|lens)\b/i, cat: "camera" },
    { kw: /\b(tv|television|oled|qled)\b/i, cat: "tv" },
    { kw: /\b(sneaker|shoe|jordan|air\s+max|yeezy)\b/i, cat: "sneakers" },
    { kw: /\b(louis\s+vuitton|gucci|chanel|hermes|prada|dior|handbag)\b/i, cat: "handbag" }
  ];
  function deriveCategory(productName) {
    for (const entry of CATEGORY_KEYWORDS) {
      if (entry.kw.test(productName)) return entry.cat;
    }
    return void 0;
  }
  function priceAnchor2(marketplace, doc = document) {
    switch (marketplace) {
      case "ebay":
        return doc.querySelector(".x-price-primary") ?? doc.querySelector("#prcIsum") ?? doc.querySelector(".x-bin-price__content") ?? null;
      case "amazon-3p":
        return doc.querySelector("#corePriceDisplay_desktop_feature_div") ?? doc.querySelector(".a-price") ?? null;
      case "fb-marketplace": {
        const main = doc.querySelector('div[role="main"]');
        if (!main) return null;
        const spans = Array.from(main.querySelectorAll("span"));
        for (const s of spans) {
          const t = (s.innerText ?? s.textContent ?? "").trim();
          if (/^\$[\d,]+(?:\.\d+)?$/.test(t)) return s;
        }
        return main.querySelector('h1[role="heading"]') ?? main.querySelector("h1") ?? null;
      }
      case "walmart-3p":
        return doc.querySelector('[data-automation-id="product-price"]');
      case "mercari":
        return doc.querySelector('[data-testid="ItemDetailsPrice"]');
      default:
        return null;
    }
  }
  async function postCounterfeitCheck(snapshot) {
    try {
      const { marketplace: _m, sellerName: _sn, sellerId: _si, ...payload } = snapshot;
      const res = await fetch(`${API_BASE4}/counterfeit/check`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) return null;
      return await res.json();
    } catch (err) {
      console.warn("[Lens] counterfeit-check fetch failed:", err.message);
      return null;
    }
  }
  function bandFor2(verdict, signalCount) {
    if (verdict === "likely-counterfeit") return "counterfeit";
    if (verdict === "caution") return "monitor";
    return signalCount === 0 ? "authentic" : "monitor";
  }
  function escapeHtml3(s) {
    return s.replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
    );
  }
  function renderBadge2(resp, anchor) {
    if (anchor.hasAttribute(BADGE_ATTR5)) return null;
    if (BADGED_ANCHORS4.has(anchor)) return null;
    if (document.querySelector('[data-lens="counterfeit-host"]')) return null;
    const failOrWarn = resp.signals.filter((s) => s.verdict !== "ok");
    const band = bandFor2(resp.verdict, failOrWarn.length);
    const ui = BAND_UI2[band];
    if (band === "authentic") {
      anchor.setAttribute(BADGE_ATTR5, "1");
      BADGED_ANCHORS4.add(anchor);
      return null;
    }
    const topSignal = failOrWarn.sort((a, b) => a.verdict === "fail" ? -1 : 1)[0];
    const headline = band === "counterfeit" ? `Likely counterfeit \u2014 ${topSignal?.detail ?? "multiple risk signals"}` : topSignal?.detail ?? "Some risk signals";
    const signalLines = failOrWarn.slice(0, 6).map((s) => `<li>${escapeHtml3(s.detail)}</li>`).join("");
    const host = document.createElement("div");
    host.setAttribute("data-lens", "counterfeit-host");
    host.style.cssText = "margin:10px 0;line-height:0;";
    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = `
    <style>
      :host, button, section, ul, li, div, span { all: initial; }
      * { box-sizing: border-box; }
      .wrap {
        display: block;
        background: ${ui.bg}; color: ${ui.color};
        border: 1px solid ${ui.border}; border-radius: 8px;
        padding: 12px 14px;
        font: 500 13px/1.5 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      }
      .head { display: flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 700; width: 100%; text-align: left; }
      .head:focus-visible { outline: 2px solid #DA7756; outline-offset: 2px; border-radius: 4px; }
      .icon { font-size: 15px; line-height: 1; }
      .label { font-weight: 700; letter-spacing: 0.01em; }
      .risk { margin-left: auto; font-family: "SF Mono", Menlo, Consolas, monospace; font-size: 12px; font-weight: 500; opacity: 0.85; }
      .status-sr { position: absolute; left: -10000px; width: 1px; height: 1px; overflow: hidden; }
      .details { margin-top: 10px; padding-top: 10px; border-top: 1px solid ${ui.border}40; display: none; }
      .details.open { display: block; }
      .details ul { margin: 0; padding: 0 0 0 18px; font-size: 12px; font-weight: 500; }
      .details li { margin: 3px 0; color: ${ui.color}; list-style: disc; }
      .caveat { margin-top: 8px; font-size: 11px; font-weight: 500; color: ${ui.color}; opacity: 0.85; }
      @media (prefers-reduced-motion: reduce) { * { transition: none !important; animation: none !important; } }
    </style>
    <section class="wrap">
      <span class="status-sr" role="status" aria-live="polite">Lens counterfeit check: ${escapeHtml3(ui.label)}. ${escapeHtml3(headline)}</span>
      <button type="button" class="head" aria-expanded="false" aria-label="${escapeHtml3(headline)}. Expand for details.">
        <span class="icon" aria-hidden="true">${ui.icon}</span>
        <span class="label">Lens: ${escapeHtml3(ui.label.toLowerCase())}</span>
        <span class="risk" aria-hidden="true">risk ${resp.riskScore}/100</span>
      </button>
      <div class="details">
        <ul>${signalLines}</ul>
        <div class="caveat">Signals from public seller + listing data. Not a guarantee; use alongside the retailer's authenticity policy.</div>
      </div>
    </section>
  `;
    const head = shadow.querySelector(".head");
    const details = shadow.querySelector(".details");
    head.addEventListener("click", () => {
      const open = details.classList.toggle("open");
      head.setAttribute("aria-expanded", open ? "true" : "false");
    });
    anchor.insertAdjacentElement("afterend", host);
    anchor.setAttribute(BADGE_ATTR5, "1");
    BADGED_ANCHORS4.add(anchor);
    return host;
  }
  function cacheKey2(snap) {
    const u = new URL(location.href);
    return `${snap.marketplace}::${u.pathname}::${snap.price ?? ""}`;
  }
  async function bootCounterfeit() {
    if (inFlight2) return;
    const marketplace = detectMarketplace();
    if (!marketplace) return;
    const hostName = location.host;
    if (getConsent(hostName) === "never") return;
    if (!canStage2(hostName)) return;
    const anchor = priceAnchor2(marketplace);
    if (!anchor) {
      console.log("[Lens] counterfeit: no price anchor on", hostName);
      return;
    }
    const snapshot = scrapeListing(marketplace);
    if (!snapshot) return;
    if (snapshot.price === void 0) return;
    if (!snapshot.category && snapshot.productName) {
      const derived = deriveCategory(snapshot.productName);
      if (derived) snapshot.category = derived;
    }
    const key = cacheKey2(snapshot);
    const cached = SCAN_CACHE2.get(key);
    if (cached && Date.now() - cached.at < SCAN_TTL_MS2) {
      renderBadge2(cached.result, anchor);
      return;
    }
    inFlight2 = true;
    try {
      const result = await postCounterfeitCheck(snapshot);
      if (!result) return;
      SCAN_CACHE2.set(key, { result, at: Date.now() });
      renderBadge2(result, anchor);
    } finally {
      inFlight2 = false;
    }
  }

  // content/visual-audit.ts
  var HOST = location.hostname;
  var RETAIL_HOSTS = new RegExp(
    "(^|\\.)(" + [
      // US big-box + marketplaces
      "amazon",
      "bestbuy",
      "walmart",
      "target",
      "homedepot",
      "costco",
      "sams",
      "lowes",
      "menards",
      "officedepot",
      "staples",
      "kohls",
      "macys",
      "nordstrom",
      "bloomingdales",
      "saksfifthavenue",
      "neimanmarcus",
      "tjmaxx",
      "rei",
      "dickssportinggoods",
      "academy",
      "newegg",
      "bhphotovideo",
      "adorama",
      "microcenter",
      "jcpenney",
      "overstock",
      "wayfair",
      "westelm",
      "cb2",
      "crateandbarrel",
      "ikea",
      "potterybarn",
      "ashleyfurniture",
      "bedbathandbeyond",
      // Marketplaces (3P heavy)
      "ebay",
      "etsy",
      "mercari",
      "poshmark",
      "depop",
      "facebook",
      "craigslist",
      "offerup",
      "alibaba",
      "aliexpress",
      "temu",
      "shein",
      "wish",
      // Grocery + food
      "kroger",
      "safeway",
      "publix",
      "wholefoodsmarket",
      "traderjoes",
      "instacart",
      "harristeeter",
      "shoprite",
      "freshdirect",
      "thrivemarket",
      "boxed",
      // Fashion + footwear
      "nike",
      "adidas",
      "underarmour",
      "lululemon",
      "uniqlo",
      "zara",
      "hm",
      "asos",
      "zappos",
      "shoebacca",
      "footlocker",
      "champssports",
      // Electronics DTC
      "apple",
      "microsoft",
      "google",
      "store.google",
      "sony",
      "samsung",
      "lg",
      "hp",
      "dell",
      "lenovo",
      "acer",
      "msi",
      "asus",
      "razer",
      "logitech",
      "anker",
      "bose",
      "sennheiser",
      "jbl",
      "sonos",
      "shure",
      // Home/kitchen DTC
      "dyson",
      "breville",
      "delonghi",
      "cuisinart",
      "kitchenaid",
      "vitamix",
      "nespresso",
      "keurig",
      "miele",
      "bosch-home",
      "geappliances",
      "whirlpool",
      "shark",
      "bissell",
      "hoover",
      "irobot",
      "roborock",
      // Pet + health
      "petsmart",
      "petco",
      "chewy",
      "cvs",
      "walgreens",
      "riteaid",
      "drugstore",
      // Automotive + outdoor
      "tesla",
      "autozone",
      "oreillyauto",
      "advanceautoparts",
      "patagonia",
      "northface",
      "columbia",
      "llbean",
      "backcountry",
      "cabelas",
      "basspro",
      "mountainhardwear",
      "arcteryx",
      // Shopify-style DTC brands
      "allbirds",
      "warbyparker",
      "caspersleep",
      "purple",
      "glossier",
      "rothys",
      "away",
      "peloton",
      "nordictrack",
      "onepeloton",
      // EU / UK
      "argos",
      "currys",
      "johnlewis",
      "selfridges",
      "marksandspencer",
      "boots",
      "lidl",
      "aldi",
      "sainsburys",
      "tesco",
      "asda",
      "mediamarkt",
      "saturn",
      "otto",
      "zalando",
      "elkjop",
      "elgiganten",
      // APAC
      "rakuten",
      "yodobashi",
      "biccamera",
      "jd",
      "tmall",
      // Canada
      "canadiantire",
      "bestbuy.ca",
      "costco.ca",
      // AU
      "coles",
      "woolworths",
      "bunnings"
    ].join("|") + ")\\.",
    "i"
  );
  if (!RETAIL_HOSTS.test(HOST)) {
  } else {
    queueMicrotask(mount);
  }
  function mount() {
    if (document.getElementById("lens-visual-pill")) return;
    const host = document.createElement("div");
    host.id = "lens-visual-pill";
    host.style.cssText = "position:fixed;right:20px;bottom:20px;z-index:2147483647;";
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
    :host { all: initial; }
    .pill {
      font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      display: flex; align-items: center; gap: 8px;
      padding: 10px 16px;
      background: #cc785c;
      color: #fff;
      border: 0;
      border-radius: 999px;
      box-shadow: 0 8px 24px rgba(204,120,92,0.3);
      cursor: pointer;
      font-weight: 600;
      letter-spacing: 0.01em;
      transition: transform 150ms cubic-bezier(0.22, 1, 0.36, 1);
    }
    .pill:hover { transform: translateY(-2px); }
    .pill .dot {
      width: 8px; height: 8px; background: #fff; border-radius: 50%;
    }
    .pill[data-busy="1"] { opacity: 0.6; cursor: wait; }
    .result {
      position: absolute; right: 0; bottom: 52px; width: 380px;
      background: #fff; color: #1a1a1a;
      border: 1px solid #e8e4dd; border-radius: 12px;
      box-shadow: 0 20px 48px rgba(0,0,0,0.15);
      padding: 20px;
      max-height: 560px; overflow-y: auto;
      font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      line-height: 1.5;
    }
    .result h4 {
      margin: 0 0 12px;
      font-size: 15px;
      font-weight: 600;
      display: flex; align-items: center; gap: 8px;
    }
    .result .row { padding: 6px 0; border-bottom: 1px solid #f3efe8; display: grid; grid-template-columns: 90px 1fr; gap: 12px; }
    .result .row:last-child { border-bottom: 0; }
    .result .k { color: #8a8a8a; font-size: 11px; text-transform: uppercase; letter-spacing: 0.06em; padding-top: 2px; }
    .result .v { color: #1a1a1a; }
    .result .badge { display: inline-block; font-size: 10px; padding: 2px 8px; border-radius: 999px; background: #faf4ee; border: 1px solid #f0e3d4; color: #8a5a3a; font-weight: 500; margin-right: 4px; }
    .result .close {
      position: absolute; top: 8px; right: 10px;
      background: none; border: 0; font-size: 20px; color: #8a8a8a; cursor: pointer;
    }
    .result .note {
      margin-top: 10px; padding: 10px; background: #faf4ee;
      border-radius: 6px; font-size: 11px; color: #6a4a3a;
    }
  `;
    const btn = document.createElement("button");
    btn.className = "pill";
    btn.innerHTML = '<span class="dot"></span><span>Lens this page</span>';
    btn.addEventListener("click", () => runVisualAudit(shadow, btn));
    shadow.append(style, btn);
    document.body.append(host);
  }
  async function runVisualAudit(shadow, btn) {
    if (btn.dataset.busy === "1") return;
    btn.dataset.busy = "1";
    const originalLabel = btn.innerHTML;
    btn.innerHTML = '<span class="dot"></span><span>Capturing + auditing\u2026</span>';
    shadow.querySelector(".result")?.remove();
    try {
      const res = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          {
            type: "LENS_VISUAL_AUDIT",
            url: location.href,
            pageTitle: document.title,
            viewport: { width: innerWidth, height: innerHeight },
            userQuery: null
          },
          (response) => resolve(response)
        );
      });
      if (!res.ok) throw new Error(res.error ?? "audit failed");
      renderResult(shadow, res.data ?? {});
    } catch (err) {
      renderError(shadow, err.message);
    } finally {
      btn.innerHTML = originalLabel;
      btn.dataset.busy = "0";
    }
  }
  function renderResult(shadow, data) {
    const ext = data.extracted ?? {};
    const panel = document.createElement("div");
    panel.className = "result";
    const price = ext.priceCurrent;
    const rating = ext.rating;
    const seller = ext.seller;
    const certs = ext.certifications ?? [];
    const bullets = ext.topBullets ?? [];
    const urgency = ext.anyUrgencyBadges ?? [];
    panel.innerHTML = `
    <button class="close" aria-label="Close">\xD7</button>
    <h4>\u{1F4E6} ${escapeHtml4(String(ext.name ?? "Unknown product"))}</h4>
    <div class="row"><div class="k">Brand</div><div class="v">${escapeHtml4(String(ext.brand ?? "\u2014"))}</div></div>
    ${ext.model ? `<div class="row"><div class="k">Model</div><div class="v">${escapeHtml4(String(ext.model))}</div></div>` : ""}
    ${price?.amount ? `<div class="row"><div class="k">Price</div><div class="v"><strong>${price.currency ?? "$"}${price.amount}</strong>${price.onSale ? '<span class="badge" style="background:#fdecec;border-color:#f5c5c5;color:#8a2f2f;margin-left:6px;">on sale</span>' : ""}</div></div>` : ""}
    ${rating?.stars ? `<div class="row"><div class="k">Rating</div><div class="v">${rating.stars}\u2605 (${rating.count ?? "?"} reviews)</div></div>` : ""}
    ${seller?.name ? `<div class="row"><div class="k">Seller</div><div class="v">${escapeHtml4(seller.name)} <span class="badge">${seller.type ?? "unknown"}</span></div></div>` : ""}
    ${ext.claimedOrigin ? `<div class="row"><div class="k">Claimed<br>origin</div><div class="v">${escapeHtml4(String(ext.claimedOrigin))}</div></div>` : ""}
    ${certs.length > 0 ? `<div class="row"><div class="k">Certs</div><div class="v">${certs.map((c) => `<span class="badge">${escapeHtml4(c)}</span>`).join(" ")}</div></div>` : ""}
    ${urgency.length > 0 ? `<div class="row"><div class="k">Urgency<br>cues</div><div class="v">${urgency.map((u) => `<span class="badge" style="background:#fdf3dc;border-color:#e5c57a;color:#9c6b14;">${escapeHtml4(u)}</span>`).join(" ")}</div></div>` : ""}
    ${bullets.length > 0 ? `<div class="row"><div class="k">Bullets</div><div class="v"><ul style="margin:0;padding-left:18px;">${bullets.slice(0, 3).map((b) => `<li>${escapeHtml4(b)}</li>`).join("")}</ul></div></div>` : ""}
    <div class="note">Parsed by Opus 4.7 vision. SKU persisted as <code>${escapeHtml4(String(data.skuId ?? "?"))}</code> in the Lens catalog. Triangulated with GS1 origin, recall database, and (if available) Keepa price history.</div>
  `;
    shadow.append(panel);
    panel.querySelector(".close")?.addEventListener("click", () => panel.remove());
  }
  function renderError(shadow, msg) {
    const panel = document.createElement("div");
    panel.className = "result";
    panel.innerHTML = `<button class="close" aria-label="Close">\xD7</button>
    <h4>Lens couldn't parse this page</h4>
    <p>${escapeHtml4(msg)}</p>
    <div class="note">Make sure you've signed in at lens-b1h.pages.dev. If the page is behind a login wall, screenshot it manually and paste on the web app.</div>`;
    shadow.append(panel);
    panel.querySelector(".close")?.addEventListener("click", () => panel.remove());
  }
  function escapeHtml4(s) {
    return s.replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
    );
  }

  // content.ts
  function detectHostLegacy() {
    const h = location.hostname;
    if (h.includes("chatgpt")) return "chatgpt";
    if (h.includes("claude.ai")) return "claude";
    if (h.includes("gemini.google")) return "gemini";
    if (h.includes("amazon")) return "rufus";
    return "unknown";
  }
  function extractLastAssistantText(host) {
    const adapter = adapterForUrl();
    if (adapter) {
      const responses = adapter.detectResponses(document);
      const last = responses.at(-1);
      return last ? adapter.extractText(last) : "";
    }
    switch (host) {
      case "chatgpt":
        return [...document.querySelectorAll('[data-message-author-role="assistant"]')].at(-1)?.textContent?.trim() ?? "";
      case "claude":
        return [...document.querySelectorAll(".font-claude-message,.font-claude-response")].at(-1)?.innerText?.trim() ?? "";
      case "gemini":
        return [...document.querySelectorAll("model-response,[data-response-id]")].at(-1)?.innerText?.trim() ?? "";
      case "rufus":
        return document.querySelector('[data-feature-name="rufus"]')?.innerText?.trim() ?? "";
      default:
        return "";
    }
  }
  function classifyPageType() {
    const u = location.href.toLowerCase();
    if (u.includes("/checkout") || u.includes("/booking/confirm") || u.includes("/payment"))
      return "checkout";
    if (u.includes("/cart")) return "cart";
    if (u.includes("/product") || u.includes("/dp/") || u.includes("/p/")) return "product";
    if (u.includes("/review")) return "review";
    if (u.includes("/marketplace") || u.includes("/seller") || u.includes("/sp/")) return "marketplace";
    return "other";
  }
  function runPassiveScan() {
    try {
      const hits = scanDocument();
      if (hits.length === 0) return;
      console.log("[Lens] detected", hits.length, "dark pattern hits:", hits);
      renderBadges(hits);
      const host = location.host;
      const pageType = classifyPageType();
      chrome.runtime.sendMessage({
        type: "LENS_SCAN_HITS",
        hits,
        host,
        pageType,
        url: location.origin + location.pathname,
        // query + fragment stripped
        stage2: false
      });
      if (canStage2(host)) {
        chrome.runtime.sendMessage({
          type: "LENS_SCAN_HITS",
          hits,
          host,
          pageType,
          url: location.origin + location.pathname,
          stage2: true
        });
        return;
      }
      if (getConsent(host) === "never") return;
      const top = pickMostSevere(hits);
      const patternName = top.brignullId.replace(/-/g, " ");
      void askForConsent(host, patternName).then((decision) => {
        if (decision === "always") {
          chrome.runtime.sendMessage({
            type: "LENS_SCAN_HITS",
            hits,
            host,
            pageType,
            url: location.origin + location.pathname,
            stage2: true
          });
        }
      });
    } catch (e) {
      console.error("[Lens] scan error:", e);
    }
  }
  function pickMostSevere(hits) {
    const order = ["illegal-in-jurisdiction", "deceptive", "manipulative", "nuisance"];
    const sorted = hits.slice().sort((a, b) => order.indexOf(a.severity) - order.indexOf(b.severity));
    return sorted[0];
  }
  function bootAIChatPills() {
    const adapter = adapterForUrl();
    if (!adapter) return;
    const inTopFrame = window === window.top;
    if (!inTopFrame && adapter.id !== "rufus") {
      return;
    }
    const mo = watchForResponses(adapter);
    console.log("[Lens] ambient pill active for host:", adapter.id, "topFrame:", inTopFrame);
  }
  var boot = () => {
    runPassiveScan();
    bootAIChatPills();
    if (window === window.top) {
      void bootPriceHistory();
      setTimeout(() => {
        void bootReviewScan();
      }, 1500);
      setTimeout(() => {
        void bootCounterfeit();
      }, 1600);
      if (isCartOrCheckout()) {
        setTimeout(() => {
          try {
            const hits = scanDocument();
            const topPattern = hits[0]?.brignullId;
            const signal = {
              confirmedCount: hits.length,
              ...topPattern ? { topPattern } : {},
              ran: "heuristic-only"
            };
            void bootCheckoutSummary(signal);
          } catch (e) {
            console.error("[Lens] cart-summary boot error:", e);
          }
        }, 1200);
      }
    }
  };
  if (document.readyState === "complete" || document.readyState === "interactive") {
    setTimeout(boot, 500);
  } else {
    document.addEventListener("DOMContentLoaded", () => setTimeout(boot, 500));
  }
  setTimeout(boot, 2500);
  function retailReboot() {
    if (window !== window.top) return;
    document.querySelectorAll('[data-lens="counterfeit-host"]').forEach((el) => el.remove());
    document.querySelectorAll("[data-lens-counterfeit]").forEach((el) => el.removeAttribute("data-lens-counterfeit"));
    void bootPriceHistory();
    void bootReviewScan();
    void bootCounterfeit();
    if (isCartOrCheckout()) {
      try {
        const hits = scanDocument();
        const topPattern = hits[0]?.brignullId;
        const signal = {
          confirmedCount: hits.length,
          ...topPattern ? { topPattern } : {},
          ran: "heuristic-only"
        };
        void bootCheckoutSummary(signal);
      } catch (e) {
        console.error("[Lens] cart-summary reboot error:", e);
      }
    }
  }
  window.addEventListener("popstate", () => setTimeout(retailReboot, 400));
  var _origPushState = history.pushState.bind(history);
  history.pushState = function(...args) {
    _origPushState(...args);
    setTimeout(retailReboot, 400);
  };
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "LENS_EXTRACT") {
      const host = detectHostLegacy();
      const raw = extractLastAssistantText(host);
      sendResponse({ host, raw });
    }
    if (msg?.type === "LENS_RESCAN") {
      runPassiveScan();
      sendResponse({ ok: true });
    }
    if (msg?.type === "LENS_STAGE2_CONFIRMED") {
      applyStage2Confirmations(msg.result);
      sendResponse({ ok: true });
    }
  });
  function applyStage2Confirmations(result) {
    for (const c of result.confirmed ?? []) {
      const host = findBadgeByBrignullId(c.brignullId);
      if (host) upgradeBadge(host, c);
    }
    for (const d of result.dismissed ?? []) {
      const brignullId = d.packSlug.replace(/^dark-pattern\//, "");
      const host = findBadgeByBrignullId(brignullId);
      if (host) host.remove();
    }
  }
})();

"use strict";
(() => {
  // background.ts
  var API_URL = "https://lens-api.webmarinelli.workers.dev";
  var hitsByTab = /* @__PURE__ */ new Map();
  var inflightByTab = /* @__PURE__ */ new Map();
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === "LENS_SCAN_HITS") {
      const tabId = sender.tab?.id;
      if (tabId) {
        hitsByTab.set(tabId, msg.hits ?? []);
        if (msg.stage2 === true && typeof msg.host === "string" && typeof msg.pageType === "string") {
          void escalateStage2(tabId, {
            host: msg.host,
            pageType: msg.pageType,
            url: typeof msg.url === "string" ? msg.url : void 0,
            hits: msg.hits ?? []
          });
        }
      }
      sendResponse({ ok: true });
      return false;
    }
    if (msg?.type === "LENS_GET_HITS") {
      const tabId = typeof msg.tabId === "number" ? msg.tabId : sender.tab?.id;
      sendResponse(tabId ? hitsByTab.get(tabId) ?? [] : []);
      return false;
    }
    if (msg?.type === "LENS_VISUAL_AUDIT") {
      void (async () => {
        try {
          const tabId = sender.tab?.id;
          if (!tabId) throw new Error("no active tab");
          const screenshotBase64 = msg.screenshotBase64;
          if (!screenshotBase64) {
            const dataUrl = await new Promise((resolve, reject) => {
              chrome.tabs.captureVisibleTab(
                sender.tab?.windowId ?? chrome.windows.WINDOW_ID_CURRENT,
                { format: "png" },
                (url) => {
                  if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                  else resolve(url);
                }
              );
            });
            msg.screenshotBase64 = dataUrl;
          }
          const res = await fetch(`${API_URL}/visual-audit`, {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              url: msg.url ?? sender.tab?.url ?? "",
              pageTitle: msg.pageTitle ?? sender.tab?.title ?? "",
              screenshotBase64: msg.screenshotBase64,
              userQuery: msg.userQuery,
              viewport: msg.viewport
            })
          });
          const data = await res.json();
          sendResponse({ ok: res.ok, data });
        } catch (err) {
          sendResponse({ ok: false, error: err.message });
        }
      })();
      return true;
    }
    if (msg?.type === "LENS_AUDIT") {
      void (async () => {
        try {
          const res = await fetch(`${API_URL}/audit`, {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify(msg.payload)
          });
          const data = await res.json();
          sendResponse({ ok: res.ok, data });
        } catch (err) {
          sendResponse({ ok: false, error: err.message });
        }
      })();
      return true;
    }
    return false;
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    hitsByTab.delete(tabId);
    inflightByTab.delete(tabId);
  });
  chrome.runtime.onInstalled.addListener(() => {
    try {
      chrome.contextMenus.create({
        id: "lens-audit-selection",
        title: "Audit with Lens",
        contexts: ["selection"]
      });
      chrome.contextMenus.create({
        id: "lens-audit-link",
        title: "Audit this product with Lens",
        contexts: ["link"]
      });
      chrome.contextMenus.create({
        id: "lens-audit-page",
        title: "Audit this page with Lens (visual)",
        contexts: ["page"],
        documentUrlPatterns: ["http://*/*", "https://*/*"]
      });
    } catch (e) {
      console.warn("[lens] contextMenus unavailable:", e.message);
    }
  });
  chrome.contextMenus?.onClicked.addListener(async (info, tab) => {
    const dashboard = "https://lens-b1h.pages.dev/";
    try {
      if (info.menuItemId === "lens-audit-selection" && info.selectionText) {
        const params = new URLSearchParams({
          mode: "text",
          source: "chatgpt",
          // guess — user can flip in the UI
          raw: info.selectionText.slice(0, 8e3)
        });
        await chrome.tabs.create({ url: `${dashboard}?${params.toString()}` });
      } else if (info.menuItemId === "lens-audit-link" && info.linkUrl) {
        const params = new URLSearchParams({ mode: "url", url: info.linkUrl });
        await chrome.tabs.create({ url: `${dashboard}?${params.toString()}` });
      } else if (info.menuItemId === "lens-audit-page" && tab?.id) {
        chrome.tabs.sendMessage(tab.id, { type: "LENS_VISUAL_AUDIT_TRIGGER" });
      }
    } catch (err) {
      console.warn("[lens:contextMenus] handler failed:", err.message);
    }
  });
  async function escalateStage2(tabId, payload) {
    if (payload.hits.length === 0) return;
    if (inflightByTab.has(tabId)) return;
    const request = fetch(`${API_URL}/passive-scan`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        host: payload.host,
        pageType: payload.pageType,
        url: payload.url,
        hits: payload.hits.map((h) => ({
          packSlug: h.packSlug,
          brignullId: h.brignullId,
          severity: h.severity,
          // Truncate excerpt at 200 chars — schema guard is 400 on the server.
          excerpt: (h.matchedElement?.text ?? "").slice(0, 200)
        }))
      })
    }).then(async (res) => {
      if (!res.ok) throw new Error(`passive-scan http ${res.status}`);
      return res.json();
    }).then((result) => {
      void chrome.tabs.sendMessage(tabId, { type: "LENS_STAGE2_CONFIRMED", result }).catch(() => {
      });
      return result;
    }).catch((err) => {
      console.error("[Lens bg] passive-scan failed:", err.message);
    }).finally(() => {
      inflightByTab.delete(tabId);
    });
    inflightByTab.set(tabId, request);
  }
})();
